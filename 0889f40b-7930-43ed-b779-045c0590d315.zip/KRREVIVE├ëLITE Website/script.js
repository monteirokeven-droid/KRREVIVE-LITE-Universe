// KRREVIVEÉLITE Universe - Main JavaScript

// Global Variables
let isLoggedIn = false;
let userSubscription = null;
let gameScore = 0;
let gameLives = 3;
let gameLevel = 1;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeModals();
    initializeAnimations();
    trackAnalytics('page_load', { page: window.location.pathname });
});

// Navigation functionality
function initializeNavigation() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // Highlight active navigation
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath.split('/').pop()) {
            link.classList.add('active');
        }
    });
}

// Modal functionality
function initializeModals() {
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('subscriptionModal');
        if (event.target === modal) {
            closeSubscriptionModal();
        }
    });
}

function showSubscriptionModal() {
    const modal = document.getElementById('subscriptionModal');
    if (modal) {
        modal.style.display = 'block';
        trackAnalytics('subscription_modal_opened');
    }
}

function closeSubscriptionModal() {
    const modal = document.getElementById('subscriptionModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Purchase functionality
function purchaseProduct(productId, price) {
    if (!isLoggedIn) {
        alert('Please log in to make a purchase.');
        window.location.href = '#login';
        return;
    }
    
    trackAnalytics('purchase_attempt', { product_id: productId, price: price });
    
    // Simulate payment processing
    if (confirm(`Confirm purchase of ${productId} for $${price}?`)) {
        // In real implementation, integrate with payment gateway
        simulatePayment(productId, price);
    }
}

function simulatePayment(productId, price) {
    // Show loading state
    const buttons = document.querySelectorAll('.btn-card');
    buttons.forEach(btn => {
        if (btn.textContent.includes('Buy') || btn.textContent.includes('Get')) {
            btn.disabled = true;
            btn.textContent = 'Processing...';
        }
    });
    
    // Simulate payment delay
    setTimeout(() => {
        alert(`Payment successful! You now have access to ${productId}.`);
        trackAnalytics('purchase_completed', { product_id: productId, price: price });
        
        // Reset buttons
        buttons.forEach(btn => {
            btn.disabled = false;
            if (btn.textContent.includes('Processing')) {
                btn.textContent = 'Purchased ✓';
                btn.style.background = 'linear-gradient(45deg, #00ff00, #00aa00)';
            }
        });
        
        // Enable premium features
        enablePremiumFeatures(productId);
    }, 2000);
}

function enablePremiumFeatures(productId) {
    // Store purchase in localStorage (in real app, this would be server-side)
    const purchases = JSON.parse(localStorage.getItem('purchases') || '[]');
    purchases.push(productId);
    localStorage.setItem('purchases', JSON.stringify(purchases));
}

function hasPurchased(productId) {
    const purchases = JSON.parse(localStorage.getItem('purchases') || '[]');
    return purchases.includes(productId);
}

// Subscription functionality
function selectSubscription(plan) {
    const prices = {
        basic: 9.99,
        pro: 19.99,
        elite: 39.99
    };
    
    trackAnalytics('subscription_selected', { plan: plan, price: prices[plan] });
    
    if (confirm(`Subscribe to ${plan.charAt(0).toUpperCase() + plan.slice(1)} plan for $${prices[plan]}/month?`)) {
        simulateSubscription(plan, prices[plan]);
    }
}

function simulateSubscription(plan, price) {
    // Show processing
    const buttons = document.querySelectorAll('.pricing-card button');
    buttons.forEach(btn => {
        if (btn.textContent.includes(plan.charAt(0).toUpperCase() + plan.slice(1))) {
            btn.disabled = true;
            btn.textContent = 'Processing...';
        }
    });
    
    setTimeout(() => {
        alert(`Successfully subscribed to ${plan.charAt(0).toUpperCase() + plan.slice(1)} plan!`);
        userSubscription = plan;
        localStorage.setItem('subscription', plan);
        trackAnalytics('subscription_completed', { plan: plan, price: price });
        closeSubscriptionModal();
        updateUIForSubscription();
    }, 2000);
}

function updateUIForSubscription() {
    // Update UI based on subscription level
    const premiumElements = document.querySelectorAll('.premium-only');
    premiumElements.forEach(element => {
        if (userSubscription === 'pro' || userSubscription === 'elite') {
            element.style.display = 'block';
        } else {
            element.style.display = 'none';
        }
    });
}

// Resume Generator functionality
function updateResumePreview() {
    const name = document.getElementById('fullName')?.value || 'Your Name';
    const email = document.getElementById('email')?.value || 'your.email@example.com';
    const phone = document.getElementById('phone')?.value || '+1 (555) 123-4567';
    const experience = document.getElementById('experience')?.value || 'Your experience details...';
    const education = document.getElementById('education')?.value || 'Your education details...';
    const skills = document.getElementById('skills')?.value || 'Your skills...';
    
    const preview = document.getElementById('resumePreviewContent');
    if (preview) {
        preview.innerHTML = `
            <div class="resume-header">
                <h2 class="resume-name">${name}</h2>
                <div class="resume-contact">${email} | ${phone}</div>
            </div>
            <div class="resume-section">
                <h3>Professional Experience</h3>
                <p>${experience}</p>
            </div>
            <div class="resume-section">
                <h3>Education</h3>
                <p>${education}</p>
            </div>
            <div class="resume-section">
                <h3>Skills</h3>
                <p>${skills}</p>
            </div>
        `;
    }
}

function downloadResume(template = 'basic') {
    if (template !== 'basic' && !hasPurchased(`resume-template-${template}`)) {
        alert('This is a premium template. Please purchase to download.');
        purchaseProduct(`resume-template-${template}`, 29.99);
        return;
    }
    
    trackAnalytics('resume_download', { template: template });
    
    // Generate PDF using jsPDF (library would be loaded in real implementation)
    if (typeof jsPDF !== 'undefined') {
        const doc = new jsPDF();
        // Add resume content to PDF
        doc.save('resume.pdf');
        alert('Resume downloaded successfully!');
    } else {
        // Fallback: create text file
        const resumeContent = generateResumeText();
        downloadFile(resumeContent, 'resume.txt', 'text/plain');
    }
}

function generateResumeText() {
    const name = document.getElementById('fullName')?.value || 'Your Name';
    const email = document.getElementById('email')?.value || 'your.email@example.com';
    const phone = document.getElementById('phone')?.value || '+1 (555) 123-4567';
    const experience = document.getElementById('experience')?.value || 'Your experience details...';
    const education = document.getElementById('education')?.value || 'Your education details...';
    const skills = document.getElementById('skills')?.value || 'Your skills...';
    
    return `RESUME - ${name}\n\n${email} | ${phone}\n\nPROFESSIONAL EXPERIENCE\n${experience}\n\nEDUCATION\n${education}\n\nSKILLS\n${skills}`;
}

function downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

// Playground functionality
let currentEditor = 'html';
const codeEditors = {
    html: '',
    css: '',
    js: ''
};

function switchEditor(language) {
    currentEditor = language;
    
    // Update tab buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Save current editor content
    const currentEditorElement = document.getElementById('codeEditor');
    if (currentEditorElement) {
        codeEditors[currentEditor] = currentEditorElement.value;
    }
    
    // Load new editor content
    if (currentEditorElement) {
        currentEditorElement.value = codeEditors[language];
    }
    
    trackAnalytics('editor_switched', { language: language });
}

function updateLivePreview() {
    const html = codeEditors.html || '<html><body><h1>Hello World</h1></body></html>';
    const css = codeEditors.css || 'body { font-family: Arial; }';
    const js = codeEditors.js || '';
    
    const preview = document.getElementById('livePreview');
    if (preview) {
        const previewDoc = preview.contentDocument || preview.contentWindow.document;
        previewDoc.open();
        previewDoc.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <style>${css}</style>
            </head>
            <body>
                ${html}
                <script>${js}<\/script>
            </body>
            </html>
        `);
        previewDoc.close();
    }
}

function loadTemplate(templateName) {
    const templates = {
        basic: {
            html: '<h1>Welcome to My Page</h1>\n<p>This is a basic template.</p>',
            css: 'h1 { color: blue; }\np { color: gray; }',
            js: 'console.log("Hello World!");'
        },
        portfolio: {
            html: '<header>\n  <h1>My Portfolio</h1>\n</header>\n<main>\n  <section id="about"></section>\n  <section id="projects"></section>\n</main>',
            css: 'header { background: #333; color: white; padding: 1rem; }\nsection { margin: 2rem 0; }',
            js: 'document.getElementById("about").innerHTML = "<h2>About Me</h2><p>I am a developer.</p>";'
        }
    };
    
    if (templates[templateName]) {
        codeEditors.html = templates[templateName].html;
        codeEditors.css = templates[templateName].css;
        codeEditors.js = templates[templateName].js;
        
        // Update current editor
        const currentEditorElement = document.getElementById('codeEditor');
        if (currentEditorElement) {
            currentEditorElement.value = codeEditors[currentEditor];
        }
        
        updateLivePreview();
        trackAnalytics('template_loaded', { template: templateName });
    }
}

function getAISuggestion() {
    if (!hasPurchased('ai-assistance')) {
        alert('AI suggestions require a Pro subscription. Upgrade now!');
        selectSubscription('pro');
        return;
    }
    
    trackAnalytics('ai_suggestion_requested');
    
    // Simulate AI suggestion
    setTimeout(() => {
        const suggestions = [
            'Consider adding a responsive design for mobile devices.',
            'Your code could benefit from semantic HTML5 elements.',
            'Try using CSS Grid for better layout control.',
            'Add some JavaScript interactivity to engage users.',
            'Consider accessibility improvements with ARIA labels.'
        ];
        
        const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
        alert(`AI Suggestion: ${randomSuggestion}`);
    }, 1500);
}

// Engineering Hub functionality
function downloadScript(scriptId, isDemo = false) {
    if (!isDemo && !hasPurchased(scriptId)) {
        alert('This is a premium script. Please purchase to download the full version.');
        purchaseProduct(scriptId, 49.99);
        return;
    }
    
    trackAnalytics('script_download', { script_id: scriptId, is_demo: isDemo });
    
    // Simulate script download
    const scriptContent = generateScriptContent(scriptId, isDemo);
    downloadFile(scriptContent, `${scriptId}.py`, 'text/plain');
    
    alert(`${isDemo ? 'Demo' : 'Full'} script downloaded successfully!`);
}

function generateScriptContent(scriptId, isDemo) {
    const scripts = {
        'automation-suite': isDemo 
            ? '# Demo version\nprint("This is a demo of the automation suite")\n# Full version includes actual automation logic'
            : '# Full Automation Suite\nimport os\nimport sys\nfrom datetime import datetime\n\ndef automate_task():\n    print("Starting automation...")\n    # Actual automation logic here\n    print("Task completed successfully!")',
        
        'data-processor': isDemo
            ? '# Demo data processor\ndef process_data():\n    print("Processing data...")\n    # Full version has complete processing logic'
            : '# Complete Data Processor\nimport pandas as pd\nimport numpy as np\n\ndef process_data(file_path):\n    df = pd.read_csv(file_path)\n    # Complete data processing logic\n    return df'
    };
    
    return scripts[scriptId] || '# Script content';
}

// Game functionality
let gameCanvas, gameCtx;
let player, enemies, bullets;
let gameRunning = false;
let animationId;

function initializeGame() {
    gameCanvas = document.getElementById('gameCanvas');
    if (!gameCanvas) return;
    
    gameCtx = gameCanvas.getContext('2d');
    
    // Set canvas size
    gameCanvas.width = 800;
    gameCanvas.height = 600;
    
    // Initialize game objects
    player = {
        x: gameCanvas.width / 2 - 25,
        y: gameCanvas.height - 60,
        width: 50,
        height: 40,
        speed: 5
    };
    
    enemies = [];
    bullets = [];
    
    // Setup keyboard controls
    setupGameControls();
}

function setupGameControls() {
    document.addEventListener('keydown', function(e) {
        if (!gameRunning) return;
        
        switch(e.key) {
            case 'ArrowLeft':
                if (player.x > 0) player.x -= player.speed;
                break;
            case 'ArrowRight':
                if (player.x < gameCanvas.width - player.width) player.x += player.speed;
                break;
            case ' ':
                shootBullet();
                break;
        }
    });
}

function startGame() {
    if (gameRunning) return;
    
    gameRunning = true;
    gameScore = 0;
    gameLives = 3;
    gameLevel = 1;
    enemies = [];
    bullets = [];
    
    updateGameDisplay();
    gameLoop();
    trackAnalytics('game_started');
}

function gameLoop() {
    if (!gameRunning) return;
    
    // Clear canvas
    gameCtx.fillStyle = '#000';
    gameCtx.fillRect(0, 0, gameCanvas.width, gameCanvas.height);
    
    // Draw player
    gameCtx.fillStyle = '#00ffea';
    gameCtx.fillRect(player.x, player.y, player.width, player.height);
    
    // Update and draw bullets
    updateBullets();
    
    // Update and draw enemies
    updateEnemies();
    
    // Check collisions
    checkCollisions();
    
    // Spawn new enemies
    if (Math.random() < 0.02 + (gameLevel * 0.005)) {
        spawnEnemy();
    }
    
    // Check level progression
    if (gameScore > gameLevel * 100) {
        gameLevel++;
        updateGameDisplay();
    }
    
    animationId = requestAnimationFrame(gameLoop);
}

function shootBullet() {
    bullets.push({
        x: player.x + player.width / 2 - 2,
        y: player.y,
        width: 4,
        height: 10,
        speed: 7
    });
}

function updateBullets() {
    gameCtx.fillStyle = '#ff00ff';
    bullets = bullets.filter(bullet => {
        bullet.y -= bullet.speed;
        gameCtx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
        return bullet.y > 0;
    });
}

function spawnEnemy() {
    enemies.push({
        x: Math.random() * (gameCanvas.width - 40),
        y: -40,
        width: 40,
        height: 30,
        speed: 1 + (gameLevel * 0.5)
    });
}

function updateEnemies() {
    gameCtx.fillStyle = '#ff0055';
    enemies = enemies.filter(enemy => {
        enemy.y += enemy.speed;
        gameCtx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
        
        // Check if enemy reached bottom
        if (enemy.y > gameCanvas.height) {
            gameLives--;
            updateGameDisplay();
            
            if (gameLives <= 0) {
                gameOver();
            }
            return false;
        }
        return true;
    });
}

function checkCollisions() {
    bullets.forEach((bullet, bulletIndex) => {
        enemies.forEach((enemy, enemyIndex) => {
            if (bullet.x < enemy.x + enemy.width &&
                bullet.x + bullet.width > enemy.x &&
                bullet.y < enemy.y + enemy.height &&
                bullet.y + bullet.height > enemy.y) {
                
                // Remove bullet and enemy
                bullets.splice(bulletIndex, 1);
                enemies.splice(enemyIndex, 1);
                
                // Increase score
                gameScore += 10;
                updateGameDisplay();
            }
        });
    });
}

function updateGameDisplay() {
    const scoreDisplay = document.getElementById('scoreDisplay');
    const livesDisplay = document.getElementById('livesDisplay');
    const levelDisplay = document.getElementById('levelDisplay');
    
    if (scoreDisplay) scoreDisplay.textContent = `Score: ${gameScore}`;
    if (livesDisplay) livesDisplay.textContent = `Lives: ${gameLives}`;
    if (levelDisplay) levelDisplay.textContent = `Level: ${gameLevel}`;
}

function gameOver() {
    gameRunning = false;
    cancelAnimationFrame(animationId);
    
    alert(`Game Over! Final Score: ${gameScore}`);
    trackAnalytics('game_over', { score: gameScore, level: gameLevel });
}

function pauseGame() {
    gameRunning = false;
    cancelAnimationFrame(animationId);
}

function resumeGame() {
    if (!gameRunning && gameLives > 0) {
        gameRunning = true;
        gameLoop();
    }
}

function upgradeGame(upgradeType) {
    const upgrades = {
        'extra-levels': { price: 9.99, id: 'extra-levels' },
        'custom-skins': { price: 4.99, id: 'custom-skins' },
        'power-ups': { price: 7.99, id: 'power-ups' }
    };
    
    const upgrade = upgrades[upgradeType];
    if (!upgrade) return;
    
    if (!hasPurchased(upgrade.id)) {
        purchaseProduct(upgrade.id, upgrade.price);
        return;
    }
    
    trackAnalytics('game_upgrade', { type: upgradeType });
    alert(`${upgradeType.replace('-', ' ').charAt(0).toUpperCase() + upgradeType.slice(1).replace('-', ' ')} activated!`);
}

// Tutorial functionality
function playTutorial(tutorialId) {
    trackAnalytics('tutorial_play', { tutorial_id: tutorialId });
    
    // Simulate video player
    alert(`Playing tutorial: ${tutorialId}`);
    // In real implementation, this would open a video player
}

function downloadTutorialPDF(tutorialId) {
    if (tutorialId === 'premium' && !hasPurchased('premium-tutorials')) {
        alert('This is a premium tutorial. Please purchase to download the full guide.');
        purchaseProduct('premium-tutorials', 19.99);
        return;
    }
    
    trackAnalytics('tutorial_pdf_download', { tutorial_id: tutorialId });
    
    const pdfContent = generateTutorialPDF(tutorialId);
    downloadFile(pdfContent, `${tutorialId}-guide.pdf`, 'application/pdf');
    
    alert('Tutorial guide downloaded successfully!');
}

function generateTutorialPDF(tutorialId) {
    const tutorials = {
        'javascript-basics': `JavaScript Basics Tutorial\n\n1. Variables and Data Types\n2. Functions and Scope\n3. Arrays and Objects\n4. DOM Manipulation\n5. Event Handling\n\nThis guide covers the fundamentals of JavaScript programming.`,
        'advanced-css': `Advanced CSS Tutorial\n\n1. Flexbox Layout\n2. CSS Grid\n3. Animations and Transitions\n4. Responsive Design\n5. CSS Custom Properties\n\nMaster advanced CSS techniques for modern web design.`,
        'premium': `Premium Web Development Guide\n\nComplete Course Content:\n\n1. HTML5 Semantic Structure\n2. Advanced CSS Techniques\n3. JavaScript ES6+ Features\n4. React.js Fundamentals\n5. Node.js Backend Development\n6. Database Integration\n7. Deployment Strategies\n8. Performance Optimization\n9. Security Best Practices\n10. Real-world Projects\n\nThis comprehensive guide covers everything you need to become a professional web developer.`
    };
    
    return tutorials[tutorialId] || 'Tutorial content';
}

// Analytics tracking
function trackAnalytics(event, data = {}) {
    // In real implementation, this would send to analytics service
    console.log('Analytics Event:', event, data);
    
    // Store in localStorage for demo purposes
    const events = JSON.parse(localStorage.getItem('analytics_events') || '[]');
    events.push({
        event: event,
        data: data,
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('analytics_events', JSON.stringify(events));
}

// Utility functions
function formatPrice(price) {
    return `$${price.toFixed(2)}`;
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'success' ? '#00ff00' : type === 'error' ? '#ff0000' : '#00ffea'};
        color: #000;
        border-radius: 8px;
        z-index: 3000;
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Animation effects
function initializeAnimations() {
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Add intersection observer for animations
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeIn 0.6s ease-out';
            }
        });
    });
    
    document.querySelectorAll('.product-card, .testimonial-card, .script-card').forEach(card => {
        observer.observe(card);
    });
}

// Form validation
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\d\s\-\+\(\)]+$/;
    return re.test(phone) && phone.replace(/\D/g, '').length >= 10;
}

// Export functions for global use
window.showSubscriptionModal = showSubscriptionModal;
window.closeSubscriptionModal = closeSubscriptionModal;
window.purchaseProduct = purchaseProduct;
window.selectSubscription = selectSubscription;
window.updateResumePreview = updateResumePreview;
window.downloadResume = downloadResume;
window.switchEditor = switchEditor;
window.updateLivePreview = updateLivePreview;
window.loadTemplate = loadTemplate;
window.getAISuggestion = getAISuggestion;
window.downloadScript = downloadScript;
window.startGame = startGame;
window.pauseGame = pauseGame;
window.resumeGame = resumeGame;
window.upgradeGame = upgradeGame;
window.playTutorial = playTutorial;
window.downloadTutorialPDF = downloadTutorialPDF;