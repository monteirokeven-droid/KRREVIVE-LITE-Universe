import { useEffect, useRef, useState } from 'react';
import { useSession } from 'next-auth/react';

interface UseSocketOptions {
  autoConnect?: boolean;
  reconnectAttempts?: number;
  reconnectDelay?: number;
}

export function useSocket(options: UseSocketOptions = {}) {
  const { data: session } = useSession();
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const socketRef = useRef<any>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const {
    autoConnect = true,
    reconnectAttempts = 5,
    reconnectDelay = 3000,
  } = options;

  let reconnectAttemptsCount = 0;

  const connect = () => {
    if (!session?.user?.id || socketRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    try {
      const wsUrl = `${process.env.NEXT_PUBLIC_WEBSOCKET_URL}?userId=${session.user.id}`;
      socketRef.current = new WebSocket(wsUrl);

      socketRef.current.onopen = () => {
        setIsConnected(true);
        setError(null);
        reconnectAttemptsCount = 0;
      };

      socketRef.current.onclose = () => {
        setIsConnected(false);
        
        if (reconnectAttemptsCount < reconnectAttempts) {
          reconnectAttemptsCount++;
          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, reconnectDelay);
        }
      };

      socketRef.current.onerror = (event) => {
        setError('Connection error');
        console.error('WebSocket error:', event);
      };

    } catch (err) {
      setError('Failed to connect');
      console.error('Connection failed:', err);
    }
  };

  const disconnect = () => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }
    
    setIsConnected(false);
  };

  const send = (type: string, data: any) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type, data }));
    }
  };

  const subscribe = (type: string, callback: (data: any) => void) => {
    if (!socketRef.current) return;

    const messageHandler = (event: MessageEvent) => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === type) {
          callback(message.data);
        }
      } catch (err) {
        console.error('Failed to parse message:', err);
      }
    };

    socketRef.current.addEventListener('message', messageHandler);

    return () => {
      if (socketRef.current) {
        socketRef.current.removeEventListener('message', messageHandler);
      }
    };
  };

  useEffect(() => {
    if (session?.user?.id && autoConnect) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [session?.user?.id, autoConnect]);

  return {
    isConnected,
    error,
    connect,
    disconnect,
    send,
    subscribe,
  };
}