import React from 'react';
import { Button } from '@/components/ui/Button';
import {
  AcademicCapIcon,
  PlayIcon,
  RocketLaunchIcon,
  UsersIcon,
} from '@heroicons/react/24/outline';

export function AcademyHero() {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-elite-purple via-elite-cyan to-elite-dark p-8 md:p-12">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid opacity-10" />
      
      <div className="relative z-10">
        <div className="max-w-4xl">
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
            <AcademicCapIcon className="h-4 w-4 text-neon-cyan" />
            <span className="text-sm text-neon-cyan font-medium">Master Key Society</span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Master Your
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple">
              Digital Destiny
            </span>
          </h1>

          {/* Description */}
          <p className="text-xl text-gray-300 mb-8 max-w-2xl">
            Unlock your full potential with our comprehensive library of courses, 
            expert instruction, and cutting-edge learning tools. Transform your 
            skills, mindset, and future in the KRREVIVEÉLITE Universe.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-6 mb-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-neon-cyan">500+</div>
              <div className="text-sm text-gray-400">Courses</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-neon-purple">50K+</div>
              <div className="text-sm text-gray-400">Students</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-neon-pink">95%</div>
              <div className="text-sm text-gray-400">Success Rate</div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button variant="default" size="lg" className="group">
              <RocketLaunchIcon className="h-5 w-5 mr-2 group-hover:animate-bounce" />
              Start Learning Free
            </Button>
            <Button variant="outline" size="lg" className="border-white/30 text-white hover:bg-white hover:text-black">
              <PlayIcon className="h-5 w-5 mr-2" />
              Watch Intro
            </Button>
          </div>

          {/* Social Proof */}
          <div className="flex items-center space-x-6 mt-8 pt-8 border-t border-white/10">
            <div className="flex -space-x-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="h-8 w-8 rounded-full bg-gradient-to-br from-neon-cyan to-neon-purple border-2 border-white/20"
                />
              ))}
            </div>
            <div className="flex items-center space-x-1">
              <UsersIcon className="h-5 w-5 text-gray-400" />
              <span className="text-sm text-gray-400">Join 50,000+ learners</span>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Elements */}
      <div className="absolute top-10 right-10 hidden lg:block">
        <div className="h-20 w-20 rounded-full bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 animate-float" />
      </div>
      <div className="absolute bottom-10 left-10 hidden lg:block">
        <div className="h-16 w-16 rounded-full bg-gradient-to-br from-neon-purple/20 to-neon-pink/20 animate-float" style={{ animationDelay: '1s' }} />
      </div>
    </div>
  );
}