import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import {
  CalendarIcon,
  FireIcon,
  BookOpenIcon,
} from '@heroicons/react/24/outline';

interface DayData {
  date: Date;
  hours: number;
  activities: number;
}

export function LearningHeatmap() {
  // Generate sample data for the last 30 days
  const generateHeatmapData = (): DayData[] => {
    const data: DayData[] = [];
    const today = new Date();
    
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      data.push({
        date,
        hours: Math.random() * 6, // 0-6 hours
        activities: Math.floor(Math.random() * 10), // 0-10 activities
      });
    }
    
    return data;
  };

  const heatmapData = generateHeatmapData();
  const totalHours = heatmapData.reduce((sum, day) => sum + day.hours, 0);
  const totalActivities = heatmapData.reduce((sum, day) => sum + day.activities, 0);
  const averageHours = (totalHours / heatmapData.length).toFixed(1);
  const mostActiveDay = heatmapData.reduce((max, day) => day.hours > max.hours ? day : max);

  const getIntensityColor = (hours: number): string => {
    if (hours === 0) return 'bg-gray-800';
    if (hours < 1) return 'bg-blue-900';
    if (hours < 2) return 'bg-blue-700';
    if (hours < 3) return 'bg-blue-500';
    if (hours < 4) return 'bg-cyan-500';
    if (hours < 5) return 'bg-green-500';
    return 'bg-green-400';
  };

  const getDayName = (date: Date): string => {
    return date.toLocaleDateString('en', { weekday: 'short' });
  };

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en', { month: 'short', day: 'numeric' });
  };

  return (
    <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <CalendarIcon className="h-5 w-5 text-cyan-500" />
          <span className="text-neon-cyan">Learning Heatmap</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Stats Overview */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/30">
            <p className="text-lg font-bold text-blue-400">{totalHours.toFixed(1)}</p>
            <p className="text-xs text-gray-400">Total Hours</p>
          </div>
          <div className="p-2 rounded-lg bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30">
            <p className="text-lg font-bold text-green-400">{totalActivities}</p>
            <p className="text-xs text-gray-400">Activities</p>
          </div>
          <div className="p-2 rounded-lg bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border border-yellow-500/30">
            <p className="text-lg font-bold text-yellow-400">{averageHours}h</p>
            <p className="text-xs text-gray-400">Daily Avg</p>
          </div>
        </div>

        {/* Heatmap Grid */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span>Last 30 days</span>
            <span>Most active: {formatDate(mostActiveDay.date)}</span>
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {/* Day headers */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-xs text-gray-500 font-medium">
                {day}
              </div>
            ))}
            
            {/* Calendar cells */}
            {heatmapData.map((day, index) => (
              <div
                key={index}
                className="relative group"
                title={`${formatDate(day.date)}: ${day.hours.toFixed(1)}h, ${day.activities} activities`}
              >
                <div
                  className={`aspect-square rounded-sm ${getIntensityColor(day.hours)} hover:ring-2 hover:ring-cyan-400 transition-all duration-200 cursor-pointer`}
                />
                
                {/* Tooltip */}
                <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-dark-200 border border-gray-700 rounded-lg p-2 text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                  <div className="font-semibold text-white">{formatDate(day.date)}</div>
                  <div className="text-gray-300">{day.hours.toFixed(1)} hours</div>
                  <div className="text-gray-400">{day.activities} activities</div>
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 rotate-45 w-2 h-2 bg-dark-200 border-r border-b border-gray-700"></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-gray-400">Less</span>
          <div className="flex space-x-1">
            <div className="w-3 h-3 rounded-sm bg-gray-800"></div>
            <div className="w-3 h-3 rounded-sm bg-blue-900"></div>
            <div className="w-3 h-3 rounded-sm bg-blue-700"></div>
            <div className="w-3 h-3 rounded-sm bg-blue-500"></div>
            <div className="w-3 h-3 rounded-sm bg-cyan-500"></div>
            <div className="w-3 h-3 rounded-sm bg-green-500"></div>
            <div className="w-3 h-3 rounded-sm bg-green-400"></div>
          </div>
          <span className="text-gray-400">More</span>
        </div>

        {/* Streak Indicator */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/30">
          <div className="flex items-center space-x-2">
            <FireIcon className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-medium text-white">7 Day Streak</span>
          </div>
          <span className="text-xs text-gray-400">Keep it going!</span>
        </div>
      </CardContent>
    </Card>
  );
}