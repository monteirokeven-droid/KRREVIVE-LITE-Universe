import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { 
  FireIcon,
  SparklesIcon,
  BookOpenIcon,
  TrophyIcon,
  ClockIcon,
  ChartBarIcon,
} from '@heroicons/react/24/outline';
import { useAuthStore } from '@/store/authStore';

export function DashboardOverview() {
  const { user, subscription, points, credits } = useAuthStore();

  const stats = [
    {
      label: 'Current Streak',
      value: '7 days',
      icon: FireIcon,
      color: 'text-red-500',
      bgColor: 'bg-red-500/10',
      borderColor: 'border-red-500/30',
    },
    {
      label: 'Experience',
      value: '2,450 XP',
      icon: SparklesIcon,
      color: 'text-cyan-500',
      bgColor: 'bg-cyan-500/10',
      borderColor: 'border-cyan-500/30',
    },
    {
      label: 'Courses Completed',
      value: '12',
      icon: BookOpenIcon,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/30',
    },
    {
      label: 'Achievements',
      value: '24',
      icon: TrophyIcon,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/30',
    },
    {
      label: 'Study Time Today',
      value: '2h 15m',
      icon: ClockIcon,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10',
      borderColor: 'border-yellow-500/30',
    },
    {
      label: 'Weekly Progress',
      value: '+15%',
      icon: ChartBarIcon,
      color: 'text-pink-500',
      bgColor: 'bg-pink-500/10',
      borderColor: 'border-pink-500/30',
    },
  ];

  return (
    <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <div className="h-6 w-6 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple animate-pulse-glow" />
          <span className="text-neon-cyan">Mission Control</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* User Status */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-neon-cyan/10 to-neon-purple/10 border border-neon-cyan/30">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple flex items-center justify-center">
              <span className="text-sm font-bold text-black">
                {user?.username?.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <p className="font-semibold text-white">{user?.username}</p>
              <p className="text-xs text-gray-400">
                {subscription === 'elite' ? 'Elite Agent' : subscription === 'premium' ? 'Premium Operator' : 'Free Explorer'}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400">Level</p>
            <p className="text-lg font-bold text-neon-cyan">12</p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`p-3 rounded-lg ${stat.bgColor} ${stat.borderColor} border`}
            >
              <div className="flex items-center justify-between">
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
                <span className="text-xs text-gray-400">{stat.label}</span>
              </div>
              <p className={`text-lg font-bold ${stat.color} mt-1`}>
                {stat.value}
              </p>
            </div>
          ))}
        </div>

        {/* Progress Overview */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Weekly Goal Progress</span>
            <span className="text-sm font-semibold text-neon-cyan">75%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div className="h-2 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple" style={{ width: '75%' }} />
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-2">
          <Button variant="default" className="w-full">
            Start Daily Mission
          </Button>
          <Button variant="outline" className="w-full">
            View Progress Report
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}