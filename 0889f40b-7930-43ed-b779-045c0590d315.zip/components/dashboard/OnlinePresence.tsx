import React from 'react';
import { Button } from '@/components/ui/Button';
import {
  SignalIcon,
  UserCircleIcon,
  CalendarIcon,
  ClockIcon,
  Cog6ToothIcon,
} from '@heroicons/react/24/outline';

export function OnlinePresence() {
  const onlineTime = '2h 35m';
  const status = 'online';
  const currentActivity = 'Studying React';

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      online: 'bg-green-500',
      offline: 'bg-gray-500',
      grinding: 'bg-red-500',
      studying: 'bg-blue-500',
      gaming: 'bg-purple-500',
    };
    return colors[status] || 'bg-gray-500';
  };

  const getStatusText = (status: string) => {
    const texts: Record<string, string> = {
      online: 'Online',
      offline: 'Offline',
      grinding: 'Grinding',
      studying: 'Studying',
      gaming: 'Gaming',
    };
    return texts[status] || 'Offline';
  };

  return (
    <div className="flex items-center space-x-4">
      {/* Status Indicator */}
      <div className="flex items-center space-x-2">
        <div className="relative">
          <div className={`h-3 w-3 rounded-full ${getStatusColor(status)} animate-pulse-glow`} />
          <div className={`absolute inset-0 h-3 w-3 rounded-full ${getStatusColor(status)} animate-ping opacity-75`} />
        </div>
        <span className="text-sm text-gray-400 hidden sm:inline">
          {getStatusText(status)}
        </span>
      </div>

      {/* Online Time */}
      <div className="flex items-center space-x-1 text-sm text-gray-400 hidden md:flex">
        <ClockIcon className="h-4 w-4" />
        <span>{onlineTime}</span>
      </div>

      {/* Current Activity */}
      <div className="flex items-center space-x-1 text-sm text-neon-cyan hidden lg:flex">
        <SignalIcon className="h-4 w-4" />
        <span>{currentActivity}</span>
      </div>

      {/* User Menu */}
      <div className="relative group">
        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
          <UserCircleIcon className="h-5 w-5" />
        </Button>
        
        {/* Dropdown */}
        <div className="absolute right-0 mt-2 w-48 rounded-md bg-dark-200 border border-gray-700 shadow-elite opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
          <div className="p-4 space-y-2">
            <div className="flex items-center space-x-2">
              <div className={`h-2 w-2 rounded-full ${getStatusColor(status)}`} />
              <span className="text-sm text-white">{getStatusText(status)}</span>
            </div>
            <div className="text-xs text-gray-400">
              Online for {onlineTime}
            </div>
            <div className="text-xs text-neon-cyan">
              {currentActivity}
            </div>
          </div>
          <div className="border-t border-gray-700 p-2">
            <button className="w-full flex items-center space-x-2 px-2 py-1 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded">
              <CalendarIcon className="h-4 w-4" />
              <span>Set Status</span>
            </button>
            <button className="w-full flex items-center space-x-2 px-2 py-1 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded">
              <Cog6ToothIcon className="h-4 w-4" />
              <span>Settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}