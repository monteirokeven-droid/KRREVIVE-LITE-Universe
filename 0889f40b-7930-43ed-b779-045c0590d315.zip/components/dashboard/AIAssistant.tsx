import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import {
  SparklesIcon,
  PaperAirplaneIcon,
  MicrophoneIcon,
  LightBulbIcon,
  DocumentTextIcon,
  ChartBarIcon,
} from '@heroicons/react/24/outline';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hello! I'm your AI assistant for the KRREVIVEÉLITE Universe. I'm here to help you with productivity, learning, goal setting, and personal growth. What can I help you achieve today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickActions = [
    {
      label: 'Generate Tasks',
      icon: DocumentTextIcon,
      color: 'text-blue-500',
      action: 'Generate personalized daily tasks based on my goals',
    },
    {
      label: 'Productivity Tips',
      icon: LightBulbIcon,
      color: 'text-yellow-500',
      action: 'Give me productivity tips for developers',
    },
    {
      label: 'Analyze Progress',
      icon: ChartBarIcon,
      color: 'text-green-500',
      action: 'Analyze my learning progress and suggest improvements',
    },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate AI response generation
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
    
    const responses = [
      "Based on your current progress, I recommend focusing on consistency over intensity. Small daily actions compound into extraordinary results over time.",
      "You're making excellent progress! Consider implementing the Pomodoro technique for better focus during study sessions.",
      "Great question! The key to mastery is deliberate practice. Focus on understanding concepts deeply rather than rushing through material.",
      "I've analyzed your patterns. You're most productive in the morning. Try scheduling your most challenging tasks during that time.",
      "Your streak is impressive! To maintain momentum, I suggest setting up accountability partnerships with fellow community members.",
      "Based on your learning style, I recommend a mix of visual and hands-on learning. Try building projects alongside your courses.",
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const aiResponse = await generateAIResponse(input);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error generating AI response:', error);
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickAction = (action: string) => {
    setInput(action);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <div className="relative">
            <SparklesIcon className="h-5 w-5 text-cyan-500" />
            <div className="absolute -top-1 -right-1 h-2 w-2 bg-green-500 rounded-full animate-pulse-glow" />
          </div>
          <span className="text-neon-cyan">AI Assistant</span>
          <span className="text-xs text-green-500">Online</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Quick Actions */}
        <div className="grid grid-cols-3 gap-2">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <button
                key={index}
                onClick={() => handleQuickAction(action.action)}
                className="flex flex-col items-center justify-center p-2 rounded-lg bg-gradient-to-br from-white/5 to-white/10 border border-gray-700 hover:border-neon-cyan/50 hover:from-neon-cyan/10 hover:to-neon-purple/10 transition-all duration-200 group"
              >
                <Icon className={`h-4 w-4 ${action.color} group-hover:scale-110 transition-transform`} />
                <span className="text-xs text-gray-400 mt-1 group-hover:text-white transition-colors">
                  {action.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Messages */}
        <div className="h-64 overflow-y-auto bg-dark-300/50 rounded-lg p-3 space-y-3 scrollbar-custom">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.type === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] p-2 rounded-lg ${
                  message.type === 'user'
                    ? 'bg-gradient-to-r from-neon-cyan to-neon-purple text-black'
                    : 'bg-dark-300 border border-gray-700 text-white'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className={`text-xs mt-1 ${
                  message.type === 'user' ? 'text-black/70' : 'text-gray-500'
                }`}>
                  {new Date(message.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-dark-300 border border-gray-700 rounded-lg p-2">
                <div className="flex space-x-1">
                  <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" />
                  <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                  <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="space-y-2">
          <div className="flex space-x-2">
            <div className="flex-1">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me anything about your growth journey..."
                className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
              />
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!input.trim() || isTyping}
              size="sm"
              className="px-3"
            >
              <PaperAirplaneIcon className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex justify-between items-center">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white text-xs">
              <MicrophoneIcon className="h-3 w-3 mr-1" />
              Voice
            </Button>
            <span className="text-xs text-gray-500">
              Powered by KRREVIVEÉLITE AI
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}