import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import {
  HeartIcon,
  ChatBubbleLeftIcon,
  ShareIcon,
  BookOpenIcon,
  TrophyIcon,
  CodeBracketIcon,
  UserGroupIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';
import { formatTimeAgo } from '@/lib/utils';

interface Activity {
  id: string;
  type: 'achievement' | 'course_complete' | 'social_post' | 'milestone' | 'streak';
  user: {
    name: string;
    avatar?: string;
    level: number;
  };
  content: string;
  timestamp: Date;
  metadata?: {
    points?: number;
    courseTitle?: string;
    achievementName?: string;
    streakDays?: number;
  };
  interactions: {
    likes: number;
    comments: number;
    shares: number;
  };
}

export function ActivityFeed() {
  const [activities] = useState<Activity[]>([
    {
      id: '1',
      type: 'achievement',
      user: {
        name: 'Alex Chen',
        level: 15,
      },
      content: 'Just unlocked the "Code Master" achievement! 100 problems solved in a row 🔥',
      timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      metadata: {
        points: 50,
        achievementName: 'Code Master',
      },
      interactions: {
        likes: 24,
        comments: 8,
        shares: 2,
      },
    },
    {
      id: '2',
      type: 'course_complete',
      user: {
        name: 'Sarah Johnson',
        level: 12,
      },
      content: 'Completed "Advanced React Patterns" course! The hooks module was mind-blowing 🚀',
      timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      metadata: {
        points: 100,
        courseTitle: 'Advanced React Patterns',
      },
      interactions: {
        likes: 42,
        comments: 15,
        shares: 5,
      },
    },
    {
      id: '3',
      type: 'streak',
      user: {
        name: 'Mike Williams',
        level: 8,
      },
      content: '30-day streak achieved! Consistency is the key to mastery 💪',
      timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      metadata: {
        points: 75,
        streakDays: 30,
      },
      interactions: {
        likes: 68,
        comments: 23,
        shares: 8,
      },
    },
    {
      id: '4',
      type: 'social_post',
      user: {
        name: 'Emily Davis',
        level: 10,
      },
      content: 'Just built my first full-stack app using Next.js! The journey from beginner to deploy feels amazing 🎯',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      interactions: {
        likes: 89,
        comments: 31,
        shares: 12,
      },
    },
    {
      id: '5',
      type: 'milestone',
      user: {
        name: 'David Martinez',
        level: 20,
      },
      content: 'Level 20 unlocked! 2000 XP reached. The grind never stops! 💯',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
      metadata: {
        points: 200,
      },
      interactions: {
        likes: 156,
        comments: 45,
        shares: 18,
      },
    },
  ]);

  const getActivityIcon = (type: string) => {
    const icons: Record<string, React.ComponentType<any>> = {
      achievement: TrophyIcon,
      course_complete: BookOpenIcon,
      social_post: ChatBubbleLeftIcon,
      milestone: CodeBracketIcon,
      streak: UserGroupIcon,
    };
    return icons[type] || ClockIcon;
  };

  const getActivityColor = (type: string) => {
    const colors: Record<string, string> = {
      achievement: 'text-yellow-500',
      course_complete: 'text-blue-500',
      social_post: 'text-cyan-500',
      milestone: 'text-purple-500',
      streak: 'text-red-500',
    };
    return colors[type] || 'text-gray-500';
  };

  const getActivityBgColor = (type: string) => {
    const colors: Record<string, string> = {
      achievement: 'bg-yellow-500/10 border-yellow-500/30',
      course_complete: 'bg-blue-500/10 border-blue-500/30',
      social_post: 'bg-cyan-500/10 border-cyan-500/30',
      milestone: 'bg-purple-500/10 border-purple-500/30',
      streak: 'bg-red-500/10 border-red-500/30',
    };
    return colors[type] || 'bg-gray-500/10 border-gray-500/30';
  };

  return (
    <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <UserGroupIcon className="h-5 w-5 text-cyan-500" />
          <span className="text-neon-cyan">Community Feed</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-custom">
          {activities.map((activity) => {
            const Icon = getActivityIcon(activity.type);
            return (
              <div
                key={activity.id}
                className={`p-3 rounded-lg border ${getActivityBgColor(activity.type)} transition-all duration-200`}
              >
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 flex items-center justify-center">
                      <span className="text-xs font-bold text-black">
                        {activity.user.name.charAt(0)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-sm font-semibold text-white">
                          {activity.user.name}
                        </h4>
                        <span className="text-xs text-neon-cyan">Lvl {activity.user.level}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon className={`h-4 w-4 ${getActivityColor(activity.type)}`} />
                        {activity.metadata?.points && (
                          <span className="text-xs font-bold text-yellow-500">
                            +{activity.metadata.points}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-300 mt-1">{activity.content}</p>
                    
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-gray-500">
                        {formatTimeAgo(activity.timestamp)}
                      </span>
                      
                      <div className="flex items-center space-x-3 text-xs text-gray-400">
                        <button className="flex items-center space-x-1 hover:text-red-400 transition-colors">
                          <HeartIcon className="h-3 w-3" />
                          <span>{activity.interactions.likes}</span>
                        </button>
                        <button className="flex items-center space-x-1 hover:text-blue-400 transition-colors">
                          <ChatBubbleLeftIcon className="h-3 w-3" />
                          <span>{activity.interactions.comments}</span>
                        </button>
                        <button className="flex items-center space-x-1 hover:text-green-400 transition-colors">
                          <ShareIcon className="h-3 w-3" />
                          <span>{activity.interactions.shares}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-2 border-t border-gray-800">
          <Button variant="default" className="w-full" size="sm">
            Create Post
          </Button>
          <Button variant="outline" className="w-full" size="sm">
            View Community
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}