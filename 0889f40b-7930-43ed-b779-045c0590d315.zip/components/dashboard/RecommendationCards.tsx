import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import {
  PlayIcon,
  BookOpenIcon,
  SparklesIcon,
  CodeBracketIcon,
  AcademicCapIcon,
  ClockIcon,
  StarIcon,
} from '@heroicons/react/24/outline';

interface Recommendation {
  id: string;
  type: 'course' | 'video' | 'tool' | 'book';
  title: string;
  description: string;
  duration?: string;
  difficulty: string;
  rating: number;
  points: number;
  imageUrl?: string;
}

export function RecommendationCards() {
  const recommendations: Recommendation[] = [
    {
      id: '1',
      type: 'course',
      title: 'Master React Hooks',
      description: 'Deep dive into custom hooks and advanced patterns',
      duration: '4 hours',
      difficulty: 'Advanced',
      rating: 4.8,
      points: 100,
      imageUrl: '/api/placeholder/300/200',
    },
    {
      id: '2',
      type: 'video',
      title: 'Productivity Hacks for Developers',
      description: '10 proven techniques to boost your coding efficiency',
      duration: '15 min',
      difficulty: 'Intermediate',
      rating: 4.6,
      points: 25,
      imageUrl: '/api/placeholder/300/200',
    },
    {
      id: '3',
      type: 'tool',
      title: 'AI Code Review Assistant',
      description: 'Automated code review with intelligent suggestions',
      difficulty: 'All Levels',
      rating: 4.9,
      points: 50,
      imageUrl: '/api/placeholder/300/200',
    },
  ];

  const getTypeIcon = (type: string) => {
    const icons: Record<string, React.ComponentType<any>> = {
      course: AcademicCapIcon,
      video: PlayIcon,
      tool: SparklesIcon,
      book: BookOpenIcon,
    };
    return icons[type] || CodeBracketIcon;
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      course: 'text-purple-500',
      video: 'text-red-500',
      tool: 'text-cyan-500',
      book: 'text-green-500',
    };
    return colors[type] || 'text-gray-500';
  };

  const getDifficultyColor = (difficulty: string) => {
    const colors: Record<string, string> = {
      Beginner: 'text-green-500',
      Intermediate: 'text-yellow-500',
      Advanced: 'text-red-500',
      'All Levels': 'text-blue-500',
    };
    return colors[difficulty] || 'text-gray-500';
  };

  return (
    <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <SparklesIcon className="h-5 w-5 text-cyan-500" />
          <span className="text-neon-cyan">AI Recommendations</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {recommendations.map((item) => {
            const Icon = getTypeIcon(item.type);
            return (
              <div
                key={item.id}
                className="p-3 rounded-lg border border-gray-700 hover:border-neon-cyan/50 transition-all duration-200 cursor-pointer group"
              >
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 flex items-center justify-center group-hover:from-neon-cyan/30 group-hover:to-neon-purple/30">
                      <Icon className={`h-6 w-6 ${getTypeColor(item.type)}`} />
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-semibold text-white group-hover:text-neon-cyan transition-colors">
                        {item.title}
                      </h4>
                      <span className="text-xs font-bold text-yellow-500">+{item.points}</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">{item.description}</p>
                    
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center space-x-3 text-xs text-gray-500">
                        <span className={`capitalize ${getDifficultyColor(item.difficulty)}`}>
                          {item.difficulty}
                        </span>
                        {item.duration && (
                          <>
                            <span>•</span>
                            <div className="flex items-center space-x-1">
                              <ClockIcon className="h-3 w-3" />
                              <span>{item.duration}</span>
                            </div>
                          </>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        <StarIcon className="h-3 w-3 text-yellow-500" />
                        <span className="text-xs text-gray-400">{item.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-2 border-t border-gray-800">
          <Button variant="default" className="w-full" size="sm">
            View All Recommendations
          </Button>
          <Button variant="outline" className="w-full" size="sm">
            Refresh AI Suggestions
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}