import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { 
  CheckCircleIcon,
  ClockIcon,
  FireIcon,
  BookOpenIcon,
  CodeBracketIcon,
  HeartIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';

interface Task {
  id: string;
  title: string;
  description: string;
  points: number;
  category: string;
  completed: boolean;
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedTime: string;
}

export function DailyTasks() {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'Complete Module 3: Advanced JavaScript',
      description: 'Finish the async/await section and complete the quiz',
      points: 50,
      category: 'learning',
      completed: false,
      difficulty: 'medium',
      estimatedTime: '45 min',
    },
    {
      id: '2',
      title: 'Meditation Session',
      description: 'Complete 15-minute mindfulness meditation',
      points: 20,
      category: 'wellness',
      completed: true,
      difficulty: 'easy',
      estimatedTime: '15 min',
    },
    {
      id: '3',
      title: 'Code Review Challenge',
      description: 'Review and improve 3 peer submissions',
      points: 30,
      category: 'coding',
      completed: false,
      difficulty: 'hard',
      estimatedTime: '30 min',
    },
    {
      id: '4',
      title: 'Read Mindset Book Chapter',
      description: 'Read chapter 5 of "Atomic Habits"',
      points: 25,
      category: 'reading',
      completed: false,
      difficulty: 'easy',
      estimatedTime: '20 min',
    },
    {
      id: '5',
      title: 'Fitness Workout',
      description: 'Complete today\'s HIIT workout routine',
      points: 35,
      category: 'health',
      completed: true,
      difficulty: 'medium',
      estimatedTime: '25 min',
    },
  ]);

  const getCategoryIcon = (category: string) => {
    const icons: Record<string, React.ComponentType<any>> = {
      learning: BookOpenIcon,
      coding: CodeBracketIcon,
      wellness: HeartIcon,
      reading: BookOpenIcon,
      health: HeartIcon,
    };
    return icons[category] || ClockIcon;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      learning: 'text-blue-500',
      coding: 'text-cyan-500',
      wellness: 'text-pink-500',
      reading: 'text-purple-500',
      health: 'text-green-500',
    };
    return colors[category] || 'text-gray-500';
  };

  const getDifficultyColor = (difficulty: string) => {
    const colors: Record<string, string> = {
      easy: 'bg-green-500/10 border-green-500/30',
      medium: 'bg-yellow-500/10 border-yellow-500/30',
      hard: 'bg-red-500/10 border-red-500/30',
    };
    return colors[difficulty] || 'bg-gray-500/10 border-gray-500/30';
  };

  const toggleTask = (taskId: string) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, completed: !task.completed } : task
    ));
  };

  const completedTasks = tasks.filter(task => task.completed).length;
  const totalPoints = tasks.filter(task => task.completed).reduce((sum, task) => sum + task.points, 0);
  const totalPossiblePoints = tasks.reduce((sum, task) => sum + task.points, 0);

  return (
    <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FireIcon className="h-5 w-5 text-red-500" />
            <span className="text-neon-cyan">Daily Missions</span>
          </div>
          <Button variant="ghost" size="sm" className="text-neon-cyan">
            <PlusIcon className="h-4 w-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress Overview */}
        <div className="p-3 rounded-lg bg-gradient-to-r from-red-500/10 to-orange-500/10 border border-red-500/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-white">Daily Progress</span>
            <span className="text-sm font-bold text-neon-cyan">{completedTasks}/{tasks.length}</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
            <div 
              className="h-2 rounded-full bg-gradient-to-r from-red-500 to-orange-500"
              style={{ width: `${(completedTasks / tasks.length) * 100}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-400">Points Earned</span>
            <span className="font-bold text-yellow-500">{totalPoints}/{totalPossiblePoints}</span>
          </div>
        </div>

        {/* Tasks List */}
        <div className="space-y-2 max-h-96 overflow-y-auto scrollbar-custom">
          {tasks.map((task) => {
            const Icon = getCategoryIcon(task.category);
            return (
              <div
                key={task.id}
                className={`p-3 rounded-lg border ${getDifficultyColor(task.difficulty)} ${
                  task.completed ? 'opacity-75' : ''
                } transition-all duration-200`}
              >
                <div className="flex items-start space-x-3">
                  <button
                    onClick={() => toggleTask(task.id)}
                    className={`mt-1 flex-shrink-0 ${
                      task.completed ? 'text-green-500' : 'text-gray-400'
                    } hover:text-green-400 transition-colors`}
                  >
                    <CheckCircleIcon className="h-5 w-5" />
                  </button>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className={`text-sm font-medium ${
                        task.completed ? 'text-gray-500 line-through' : 'text-white'
                      }`}>
                        {task.title}
                      </h4>
                      <div className="flex items-center space-x-2">
                        <Icon className={`h-4 w-4 ${getCategoryColor(task.category)}`} />
                        <span className="text-xs font-bold text-yellow-500">+{task.points}</span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">{task.description}</p>
                    <div className="flex items-center space-x-3 mt-2 text-xs text-gray-500">
                      <span>{task.category}</span>
                      <span>•</span>
                      <span>{task.estimatedTime}</span>
                      <span>•</span>
                      <span className="capitalize">{task.difficulty}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="space-y-2 pt-2 border-t border-gray-800">
          <Button variant="default" className="w-full" size="sm">
            Generate AI Tasks
          </Button>
          <Button variant="outline" className="w-full" size="sm">
            View Weekly Goals
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}