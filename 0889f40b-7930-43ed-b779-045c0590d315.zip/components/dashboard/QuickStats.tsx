import React from 'react';
import { Card, CardContent } from '@/components/ui/Card';
import {
  FireIcon,
  SparklesIcon,
  BookOpenIcon,
  TrophyIcon,
  ClockIcon,
  ChartBarIcon,
} from '@heroicons/react/24/outline';

export function QuickStats() {
  const stats = [
    {
      label: 'Current Streak',
      value: '7',
      unit: 'days',
      icon: FireIcon,
      color: 'from-red-500 to-orange-500',
      bgColor: 'from-red-500/10 to-orange-500/10',
      borderColor: 'border-red-500/30',
      change: '+2 days',
      changeType: 'positive',
    },
    {
      label: 'Total Points',
      value: '2,450',
      unit: 'XP',
      icon: SparklesIcon,
      color: 'from-cyan-500 to-blue-500',
      bgColor: 'from-cyan-500/10 to-blue-500/10',
      borderColor: 'border-cyan-500/30',
      change: '+150 XP',
      changeType: 'positive',
    },
    {
      label: 'Courses Completed',
      value: '12',
      unit: 'courses',
      icon: BookOpenIcon,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'from-green-500/10 to-emerald-500/10',
      borderColor: 'border-green-500/30',
      change: '+2 this week',
      changeType: 'positive',
    },
    {
      label: 'Achievements',
      value: '24',
      unit: 'badges',
      icon: TrophyIcon,
      color: 'from-purple-500 to-pink-500',
      bgColor: 'from-purple-500/10 to-pink-500/10',
      borderColor: 'border-purple-500/30',
      change: '+1 new',
      changeType: 'positive',
    },
    {
      label: 'Study Time Today',
      value: '2h 15m',
      unit: 'today',
      icon: ClockIcon,
      color: 'from-yellow-500 to-amber-500',
      bgColor: 'from-yellow-500/10 to-amber-500/10',
      borderColor: 'border-yellow-500/30',
      change: '+30 min',
      changeType: 'positive',
    },
    {
      label: 'Weekly Progress',
      value: '+15',
      unit: '%',
      icon: ChartBarIcon,
      color: 'from-blue-500 to-indigo-500',
      bgColor: 'from-blue-500/10 to-indigo-500/10',
      borderColor: 'border-blue-500/30',
      change: '+5%',
      changeType: 'positive',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card
            key={index}
            className={`border-gray-800 bg-gradient-to-br ${stat.bgColor} ${stat.borderColor} hover:shadow-lg hover:shadow-neon-cyan/20 transition-all duration-300 cursor-pointer group`}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.color} group-hover:scale-110 transition-transform`}>
                  <Icon className="h-4 w-4 text-white" />
                </div>
                <span className={`text-xs font-medium ${
                  stat.changeType === 'positive' ? 'text-green-500' : 'text-red-500'
                }`}>
                  {stat.change}
                </span>
              </div>
              
              <div className="space-y-1">
                <div className="flex items-baseline space-x-1">
                  <span className="text-2xl font-bold text-white group-hover:text-neon-cyan transition-colors">
                    {stat.value}
                  </span>
                  <span className="text-xs text-gray-400">{stat.unit}</span>
                </div>
                <p className="text-xs text-gray-400">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}