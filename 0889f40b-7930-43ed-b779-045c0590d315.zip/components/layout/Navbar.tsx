import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { useUIStore } from '@/store/uiStore';
import { Button } from '@/components/ui/Button';
import {
  HomeIcon,
  BookOpenIcon,
  PuzzlePieceIcon,
  SparklesIcon,
  AcademicCapIcon,
  GamepadIcon,
  UserCircleIcon,
  ShoppingCartIcon,
  Bars3Icon,
  XMarkIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
  CrownIcon,
} from '@heroicons/react/24/outline';
import { cn } from '@/lib/utils';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: HomeIcon },
  { name: 'Academy', href: '/academy', icon: AcademicCapIcon },
  { name: 'Playground', href: '/playground', icon: PuzzlePieceIcon },
  { name: 'Tools', href: '/tools', icon: SparklesIcon },
  { name: 'Entertainment', href: '/entertainment', icon: GamepadIcon },
  { name: 'Store', href: '/store', icon: ShoppingCartIcon },
];

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const { user, isAuthenticated } = useAuth(true);
  const { sidebarOpen, setSidebarOpen } = useUIStore();

  const handleLogout = async () => {
    // Implement logout logic
    window.location.href = '/auth/signout';
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-dark-100 via-elite-dark to-dark-100 border-b border-gray-800 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden text-neon-cyan"
            >
              <Bars3Icon className="h-6 w-6" />
            </Button>
            
            <Link href="/dashboard" className="flex items-center space-x-3 ml-2 lg:ml-0">
              <div className="relative">
                <div className="h-8 w-8 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple animate-pulse-glow" />
                <div className="absolute inset-0 h-8 w-8 rounded-full bg-gradient-to-r from-neon-purple to-neon-pink opacity-50 animate-pulse-glow" />
              </div>
              <span className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple">
                KRREVIVEÉLITE
              </span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex lg:items-center lg:space-x-1">
            {navigation.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    'flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200',
                    isActive
                      ? 'bg-gradient-to-r from-neon-cyan/20 to-neon-purple/20 text-neon-cyan border border-neon-cyan/50'
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </div>

          {/* User Menu */}
          <div className="flex items-center space-x-3">
            {/* Credits & Points */}
            {isAuthenticated && (
              <div className="hidden sm:flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-1 text-yellow-500">
                  <CrownIcon className="h-4 w-4" />
                  <span>{user?.credits || 0}</span>
                </div>
                <div className="flex items-center space-x-1 text-neon-cyan">
                  <SparklesIcon className="h-4 w-4" />
                  <span>{user?.points || 0}</span>
                </div>
              </div>
            )}

            {/* User Avatar & Menu */}
            {isAuthenticated ? (
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex items-center space-x-2 text-white hover:bg-white/10"
                >
                  <div className="h-8 w-8 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple flex items-center justify-center">
                    <span className="text-xs font-bold text-black">
                      {user?.username?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <span className="hidden sm:inline">{user?.username}</span>
                </Button>

                {/* Dropdown Menu */}
                <div className="absolute right-0 mt-2 w-48 rounded-md bg-dark-200 border border-gray-700 shadow-elite opacity-0 invisible hover:opacity-100 hover:visible transition-all duration-200">
                  <div className="py-1">
                    <Link
                      href="/profile"
                      className="flex items-center px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10"
                    >
                      <UserCircleIcon className="h-4 w-4 mr-2" />
                      Profile
                    </Link>
                    <Link
                      href="/settings"
                      className="flex items-center px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10"
                    >
                      <Cog6ToothIcon className="h-4 w-4 mr-2" />
                      Settings
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10"
                    >
                      <ArrowRightOnRectangleIcon className="h-4 w-4 mr-2" />
                      Sign Out
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/auth/signin">
                  <Button variant="outline" size="sm">
                    Sign In
                  </Button>
                </Link>
                <Link href="/auth/signup">
                  <Button size="sm">
                    Get Started
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden text-white hover:bg-white/10"
            >
              {mobileMenuOpen ? (
                <XMarkIcon className="h-6 w-6" />
              ) : (
                <Bars3Icon className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-800">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigation.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      'flex items-center space-x-2 px-3 py-2 rounded-md text-base font-medium transition-all duration-200',
                      isActive
                        ? 'bg-gradient-to-r from-neon-cyan/20 to-neon-purple/20 text-neon-cyan border border-neon-cyan/50'
                        : 'text-gray-300 hover:text-white hover:bg-white/10'
                    )}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </div>
            {!isAuthenticated && (
              <div className="px-2 pt-4 pb-3 border-t border-gray-800">
                <div className="flex items-center space-x-2">
                  <Link href="/auth/signin" className="flex-1">
                    <Button variant="outline" size="sm" className="w-full">
                      Sign In
                    </Button>
                  </Link>
                  <Link href="/auth/signup" className="flex-1">
                    <Button size="sm" className="w-full">
                      Get Started
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}