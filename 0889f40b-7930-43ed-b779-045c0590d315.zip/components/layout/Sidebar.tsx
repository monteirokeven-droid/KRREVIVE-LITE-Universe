import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useUIStore } from '@/store/uiStore';
import { useAuthStore } from '@/store/authStore';
import { cn } from '@/lib/utils';
import {
  HomeIcon,
  AcademicCapIcon,
  BookOpenIcon,
  SparklesIcon,
  PuzzlePieceIcon,
  GamepadIcon,
  ShoppingCartIcon,
  ChartBarIcon,
  UserGroupIcon,
  BellIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
  TrophyIcon,
  FireIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';

const sidebarNavigation = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: HomeIcon,
    current: false,
  },
  {
    name: 'Academy',
    href: '/academy',
    icon: AcademicCapIcon,
    current: false,
  },
  {
    name: 'Courses',
    href: '/courses',
    icon: BookOpenIcon,
    current: false,
  },
  {
    name: 'Tools',
    href: '/tools',
    icon: SparklesIcon,
    current: false,
  },
  {
    name: 'Playground',
    href: '/playground',
    icon: PuzzlePieceIcon,
    current: false,
  },
  {
    name: 'Entertainment',
    href: '/entertainment',
    icon: GamepadIcon,
    current: false,
  },
  {
    name: 'Store',
    href: '/store',
    icon: ShoppingCartIcon,
    current: false,
  },
  {
    name: 'Analytics',
    href: '/analytics',
    icon: ChartBarIcon,
    current: false,
  },
  {
    name: 'Community',
    href: '/community',
    icon: UserGroupIcon,
    current: false,
  },
];

const secondaryNavigation = [
  { name: 'Achievements', href: '/achievements', icon: TrophyIcon },
  { name: 'Streaks', href: '/streaks', icon: FireIcon },
  { name: 'Schedule', href: '/schedule', icon: ClockIcon },
];

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarOpen, setSidebarOpen, setActiveModule } = useUIStore();
  const { user, subscription, points, credits } = useAuthStore();

  const handleNavigation = (href: string, moduleName: string) => {
    setActiveModule(moduleName);
    // Close sidebar on mobile after navigation
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-25 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={cn(
          'fixed inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-dark-100 to-dark-200 border-r border-gray-800 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo and Brand */}
          <div className="flex h-16 items-center px-6 border-b border-gray-800">
            <div className="flex items-center space-x-3">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple animate-pulse-glow" />
              <span className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple">
                KRREVIVEÉLITE
              </span>
            </div>
          </div>

          {/* User Info */}
          {user && (
            <div className="px-6 py-4 border-b border-gray-800">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple flex items-center justify-center">
                  <span className="text-sm font-bold text-black">
                    {user.username?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">
                    {user.username}
                  </p>
                  <p className="text-xs text-gray-400 truncate">
                    {subscription === 'elite' ? 'Elite' : subscription === 'premium' ? 'Premium' : 'Free'} Member
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between mt-3 text-xs">
                <div className="flex items-center space-x-1 text-yellow-500">
                  <span>💰</span>
                  <span>{credits}</span>
                </div>
                <div className="flex items-center space-x-1 text-neon-cyan">
                  <span>⚡</span>
                  <span>{points}</span>
                </div>
              </div>
            </div>
          )}

          {/* Main Navigation */}
          <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
            {sidebarNavigation.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => handleNavigation(item.href, item.name)}
                  className={cn(
                    'group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-200',
                    isActive
                      ? 'bg-gradient-to-r from-neon-cyan/20 to-neon-purple/20 text-neon-cyan border border-neon-cyan/50'
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  )}
                >
                  <item.icon
                    className={cn(
                      'mr-3 h-5 w-5 flex-shrink-0',
                      isActive ? 'text-neon-cyan' : 'text-gray-400 group-hover:text-gray-300'
                    )}
                  />
                  {item.name}
                </Link>
              );
            })}

            {/* Secondary Navigation */}
            <div className="mt-6 pt-6 border-t border-gray-800">
              <div className="px-3 mb-2">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
                  Personal
                </p>
              </div>
              {secondaryNavigation.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      'group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-200',
                      isActive
                        ? 'bg-gradient-to-r from-neon-cyan/20 to-neon-purple/20 text-neon-cyan border border-neon-cyan/50'
                        : 'text-gray-300 hover:text-white hover:bg-white/10'
                    )}
                  >
                    <item.icon
                      className={cn(
                        'mr-3 h-5 w-5 flex-shrink-0',
                        isActive ? 'text-neon-cyan' : 'text-gray-400 group-hover:text-gray-300'
                      )}
                    />
                    {item.name}
                  </Link>
                );
              })}
            </div>
          </nav>

          {/* Bottom Actions */}
          <div className="px-4 py-4 border-t border-gray-800">
            <div className="space-y-1">
              <Link
                href="/notifications"
                className="group flex items-center px-3 py-2 text-sm font-medium text-gray-300 rounded-md hover:text-white hover:bg-white/10"
              >
                <BellIcon className="mr-3 h-5 w-5 text-gray-400 group-hover:text-gray-300" />
                Notifications
              </Link>
              <Link
                href="/settings"
                className="group flex items-center px-3 py-2 text-sm font-medium text-gray-300 rounded-md hover:text-white hover:bg-white/10"
              >
                <Cog6ToothIcon className="mr-3 h-5 w-5 text-gray-400 group-hover:text-gray-300" />
                Settings
              </Link>
              <button
                onClick={() => window.location.href = '/auth/signout'}
                className="group flex items-center w-full px-3 py-2 text-sm font-medium text-gray-300 rounded-md hover:text-white hover:bg-white/10"
              >
                <ArrowRightOnRectangleIcon className="mr-3 h-5 w-5 text-gray-400 group-hover:text-gray-300" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}