import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { Providers } from './providers';
import { Navbar } from '@/components/layout/Navbar';
import { Sidebar } from '@/components/layout/Sidebar';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'KRREVIVEÉLITE Universe - 24/7 Digital Ecosystem',
  description: 'Transform your life with our comprehensive platform featuring courses, tools, entertainment, and community for personal growth and success.',
  keywords: ['personal development', 'online learning', 'productivity tools', 'gaming', 'community', 'KRREVIVEÉLITE'],
  authors: [{ name: 'KRREVIVEÉLITE Universe' }],
  creator: 'KRREVIVEÉLITE',
  publisher: 'KRREVIVEÉLITE',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className={inter.className}>
        <Providers>
          <div className="min-h-screen bg-dark-DEFAULT">
            <Navbar />
            <div className="flex pt-16">
              <Sidebar />
              <main className="flex-1 lg:ml-64">
                <div className="container mx-auto px-4 py-6">
                  {children}
                </div>
              </main>
            </div>
          </div>
        </Providers>
      </body>
    </html>
  );
}