import React from 'react';
import { DashboardOverview } from '@/components/dashboard/DashboardOverview';
import { DailyTasks } from '@/components/dashboard/DailyTasks';
import { RecommendationCards } from '@/components/dashboard/RecommendationCards';
import { ActivityFeed } from '@/components/dashboard/ActivityFeed';
import { OnlinePresence } from '@/components/dashboard/OnlinePresence';
import { AIAssistant } from '@/components/dashboard/AIAssistant';
import { QuickStats } from '@/components/dashboard/QuickStats';
import { LearningHeatmap } from '@/components/dashboard/LearningHeatmap';

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple">
            Digital Control Center
          </h1>
          <p className="text-gray-400 mt-2">
            Your 24/7 command center for growth, learning, and domination
          </p>
        </div>
        <OnlinePresence />
      </div>

      {/* Quick Stats */}
      <QuickStats />

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Daily Tasks & Goals */}
        <div className="lg:col-span-1 space-y-6">
          <DailyTasks />
          <LearningHeatmap />
        </div>

        {/* Middle Column - Overview & Recommendations */}
        <div className="lg:col-span-1 space-y-6">
          <DashboardOverview />
          <RecommendationCards />
        </div>

        {/* Right Column - Activity Feed & AI Assistant */}
        <div className="lg:col-span-1 space-y-6">
          <ActivityFeed />
          <AIAssistant />
        </div>
      </div>
    </div>
  );
}