import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { users } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const token = searchParams.get('token');

    if (!token) {
      return NextResponse.json(
        { error: 'Verification token is required' },
        { status: 400 }
      );
    }

    // Find user with verification token
    const user = await db
      .select()
      .from(users)
      .where(eq(users.metadata, { verificationToken: token }))
      .limit(1);

    if (!user.length) {
      return NextResponse.json(
        { error: 'Invalid verification token' },
        { status: 400 }
      );
    }

    const userData = user[0];
    const metadata = userData.metadata as any;

    // Check if token has expired
    if (new Date(metadata.verificationExpires) < new Date()) {
      return NextResponse.json(
        { error: 'Verification token has expired' },
        { status: 400 }
      );
    }

    // Verify email
    await db
      .update(users)
      .set({
        emailVerified: true,
        metadata: {
          ...metadata,
          verificationToken: null,
          verificationExpires: null,
        },
      })
      .where(eq(users.id, userData.id));

    // Send welcome email
    await sendWelcomeEmail(userData.email, userData.username);

    return NextResponse.json({
      success: true,
      message: 'Email verified successfully! You can now sign in.',
    });
  } catch (error) {
    console.error('Email verification error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

async function sendWelcomeEmail(email: string, username: string) {
  // Import here to avoid circular dependency
  const { sendWelcomeEmail } = await import('@/lib/email');
  await sendWelcomeEmail(email, username);
}