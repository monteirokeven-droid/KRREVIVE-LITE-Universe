import { NextRequest, NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { stripe } from '@/lib/stripe';
import { db } from '@/lib/db';
import { users, subscriptions, purchases, products } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { sendVerificationEmail } from '@/lib/email';

export async function POST(request: NextRequest) {
  const body = await request.text();
  const signature = headers().get('stripe-signature');

  if (!signature) {
    return NextResponse.json(
      { error: 'Missing Stripe signature' },
      { status: 400 }
    );
  }

  let event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    return NextResponse.json(
      { error: 'Webhook signature verification failed' },
      { status: 400 }
    );
  }

  switch (event.type) {
    case 'checkout.session.completed':
      await handleCheckoutCompleted(event.data.object);
      break;
    case 'invoice.payment_succeeded':
      await handleInvoicePaymentSucceeded(event.data.object);
      break;
    case 'customer.subscription.deleted':
      await handleSubscriptionDeleted(event.data.object);
      break;
    case 'payment_intent.succeeded':
      await handlePaymentSucceeded(event.data.object);
      break;
    default:
      console.log(`Unhandled event type: ${event.type}`);
  }

  return NextResponse.json({ received: true });
}

async function handleCheckoutCompleted(session: any) {
  const userId = session.metadata?.userId;

  if (!userId) {
    console.error('No user ID found in session metadata');
    return;
  }

  // Update user's Stripe customer ID
  await db
    .update(users)
    .set({
      stripeCustomerId: session.customer,
    })
    .where(eq(users.id, userId));

  console.log(`Checkout completed for user ${userId}`);
}

async function handleInvoicePaymentSucceeded(invoice: any) {
  const subscriptionId = invoice.subscription;
  const customerId = invoice.customer;

  if (!subscriptionId || !customerId) {
    console.error('Missing subscription or customer ID');
    return;
  }

  // Get subscription details
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  const user = await db
    .select()
    .from(users)
    .where(eq(users.stripeCustomerId, customerId))
    .limit(1);

  if (!user.length) {
    console.error('User not found for customer ID:', customerId);
    return;
  }

  const tier = getTierFromPrice(subscription.items.data[0].price.id);
  
  // Update or create subscription
  await db
    .insert(subscriptions)
    .values({
      userId: user[0].id,
      tier,
      stripeSubscriptionId: subscriptionId,
      status: subscription.status,
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    })
    .onConflictDoUpdate({
      target: subscriptions.stripeSubscriptionId,
      set: {
        tier,
        status: subscription.status,
        currentPeriodStart: new Date(subscription.current_period_start * 1000),
        currentPeriodEnd: new Date(subscription.current_period_end * 1000),
        cancelAtPeriodEnd: subscription.cancel_at_period_end,
      },
    });

  // Update user's subscription tier
  await db
    .update(users)
    .set({
      subscriptionTier: tier,
      subscriptionEndsAt: new Date(subscription.current_period_end * 1000),
    })
    .where(eq(users.id, user[0].id));

  console.log(`Subscription updated for user ${user[0].id}: ${tier}`);
}

async function handleSubscriptionDeleted(subscription: any) {
  const customerId = subscription.customer;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.stripeCustomerId, customerId))
    .limit(1);

  if (!user.length) {
    console.error('User not found for customer ID:', customerId);
    return;
  }

  // Update subscription status
  await db
    .update(subscriptions)
    .set({
      status: 'canceled',
    })
    .where(eq(subscriptions.stripeSubscriptionId, subscription.id));

  // Downgrade user to free tier at end of period
  await db
    .update(users)
    .set({
      subscriptionTier: 'free',
    })
    .where(eq(users.id, user[0].id));

  console.log(`Subscription canceled for user ${user[0].id}`);
}

async function handlePaymentSucceeded(paymentIntent: any) {
  // This handles one-time payments for products
  const metadata = paymentIntent.metadata;
  
  if (!metadata?.userId || !metadata?.productId) {
    console.error('Missing metadata in payment intent');
    return;
  }

  // Get product details
  const product = await db
    .select()
    .from(products)
    .where(eq(products.id, metadata.productId))
    .limit(1);

  if (!product.length) {
    console.error('Product not found:', metadata.productId);
    return;
  }

  // Create purchase record
  await db.insert(purchases).values({
    userId: metadata.userId,
    productId: metadata.productId,
    stripePaymentId: paymentIntent.id,
    amount: paymentIntent.amount / 100, // Convert from cents
    status: 'completed',
    licenseKey: generateLicenseKey(),
  });

  console.log(`Payment completed for user ${metadata.userId}, product ${metadata.productId}`);
}

function getTierFromPrice(priceId: string): 'free' | 'premium' | 'elite' {
  // Map Stripe price IDs to subscription tiers
  // This should be based on your actual Stripe prices
  const priceMap: Record<string, 'free' | 'premium' | 'elite'> = {
    'price_premium_monthly': 'premium',
    'price_elite_monthly': 'elite',
    'price_premium_yearly': 'premium',
    'price_elite_yearly': 'elite',
  };

  return priceMap[priceId] || 'free';
}

function generateLicenseKey(): string {
  return 'KR-' + Math.random().toString(36).substring(2, 15).toUpperCase();
}