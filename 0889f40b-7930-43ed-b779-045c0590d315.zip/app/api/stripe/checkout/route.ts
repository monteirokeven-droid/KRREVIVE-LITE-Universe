import { NextRequest, NextResponse } from 'next/server';
import { createCheckoutSession, createPaymentSession } from '@/lib/stripe';
import { db } from '@/lib/db';
import { users } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  try {
    const { priceId, type, userId } = await request.json();

    if (!priceId || !type || !userId) {
      return NextResponse.json(
        { error: 'Price ID, type, and user ID are required' },
        { status: 400 }
      );
    }

    // Verify user exists
    const user = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user.length) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const successUrl = `${process.env.NEXT_PUBLIC_APP_URL}/success?session_id={CHECKOUT_SESSION_ID}`;
    const cancelUrl = `${process.env.NEXT_PUBLIC_APP_URL}/pricing`;

    let session;

    if (type === 'subscription') {
      session = await createCheckoutSession({
        userId,
        priceId,
        successUrl,
        cancelUrl,
      });
    } else {
      session = await createPaymentSession({
        userId,
        priceId,
        successUrl,
        cancelUrl,
      });
    }

    return NextResponse.json({
      success: true,
      sessionId: session.id,
      url: session.url,
    });
  } catch (error) {
    console.error('Checkout session error:', error);
    return NextResponse.json(
      { error: 'Failed to create checkout session' },
      { status: 500 }
    );
  }
}