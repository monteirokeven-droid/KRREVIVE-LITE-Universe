import React, { useState } from 'react';
import { signIn, getSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { toast } from 'react-hot-toast';
import {
  EyeIcon,
  EyeSlashIcon,
  SparklesIcon,
  ArrowRightOnRectangleIcon,
} from '@heroicons/react/24/outline';

export default function SignInPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const result = await signIn('credentials', {
        email,
        password,
        redirect: false,
      });

      if (result?.error) {
        toast.error('Invalid email or password');
      } else {
        toast.success('Signed in successfully!');
        router.push('/dashboard');
      }
    } catch (error) {
      toast.error('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-DEFAULT via-elite-dark to-dark-100 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-grid-dark opacity-20" />
      
      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3">
            <div className="h-12 w-12 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple animate-pulse-glow" />
            <span className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple">
              KRREVIVEÉLITE
            </span>
          </div>
          <p className="text-gray-400 mt-2">Sign in to your universe</p>
        </div>

        <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200 shadow-elite">
          <CardHeader>
            <CardTitle className="text-center text-neon-cyan">
              Welcome Back
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  type="email"
                  label="Email Address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
                />
              </div>

              <div>
                <Input
                  type={showPassword ? 'text' : 'password'}
                  label="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="mt-2 flex items-center space-x-1 text-sm text-gray-400 hover:text-neon-cyan transition-colors"
                >
                  {showPassword ? (
                    <EyeSlashIcon className="h-4 w-4" />
                  ) : (
                    <EyeIcon className="h-4 w-4" />
                  )}
                  <span>{showPassword ? 'Hide' : 'Show'} password</span>
                </button>
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center space-x-2 text-sm text-gray-400">
                  <input
                    type="checkbox"
                    className="rounded border-gray-700 bg-dark-300/50 text-neon-cyan focus:ring-neon-cyan focus:ring-offset-dark-100"
                  />
                  <span>Remember me</span>
                </label>
                <Link
                  href="/auth/forgot-password"
                  className="text-sm text-neon-cyan hover:text-neon-purple transition-colors"
                >
                  Forgot password?
                </Link>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
                size="lg"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Signing in...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <ArrowRightOnRectangleIcon className="h-5 w-5" />
                    <span>Sign In</span>
                  </div>
                )}
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-700" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-dark-200 text-gray-400">
                  New to KRREVIVEÉLITE?
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <Link href="/auth/signup">
                <Button variant="outline" className="w-full">
                  <SparklesIcon className="h-5 w-5 mr-2" />
                  Create your account
                </Button>
              </Link>

              {/* Social login options */}
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="ghost"
                  className="border-gray-700 hover:border-neon-cyan"
                  size="sm"
                >
                  Google
                </Button>
                <Button
                  variant="ghost"
                  className="border-gray-700 hover:border-neon-purple"
                  size="sm"
                >
                  GitHub
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-gray-500 mt-6">
          By signing in, you agree to our{' '}
          <Link href="/terms" className="text-neon-cyan hover:text-neon-purple">
            Terms of Service
          </Link>{' '}
          and{' '}
          <Link href="/privacy" className="text-neon-cyan hover:text-neon-purple">
            Privacy Policy
          </Link>
        </p>
      </div>
    </div>
  );
}