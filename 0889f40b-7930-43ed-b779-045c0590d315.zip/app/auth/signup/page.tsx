import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { toast } from 'react-hot-toast';
import {
  EyeIcon,
  EyeSlashIcon,
  SparklesIcon,
  UserAddIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline';
import { validatePassword } from '@/lib/utils';

export default function SignUpPage() {
  const [formData, setFormData] = useState({
    email: '',
    username: '',
    password: '',
    firstName: '',
    lastName: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [passwordValidation, setPasswordValidation] = useState({
    isValid: false,
    errors: [] as string[],
  });
  const router = useRouter();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    if (field === 'password') {
      const validation = validatePassword(value);
      setPasswordValidation(validation);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!passwordValidation.isValid) {
      toast.error('Please fix the password errors');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Account created successfully! Please check your email.');
        router.push('/auth/signin');
      } else {
        toast.error(data.error || 'Registration failed');
      }
    } catch (error) {
      toast.error('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-DEFAULT via-elite-dark to-dark-100 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-grid-dark opacity-20" />
      
      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3">
            <div className="h-12 w-12 rounded-full bg-gradient-to-r from-neon-cyan to-neon-purple animate-pulse-glow" />
            <span className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple">
              KRREVIVEÉLITE
            </span>
          </div>
          <p className="text-gray-400 mt-2">Join the universe of endless possibilities</p>
        </div>

        <Card className="border-gray-800 bg-gradient-to-br from-dark-100 to-dark-200 shadow-elite">
          <CardHeader>
            <CardTitle className="text-center text-neon-cyan">
              Create Your Account
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Input
                    type="text"
                    label="First Name"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                    placeholder="John"
                    className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
                  />
                </div>
                <div>
                  <Input
                    type="text"
                    label="Last Name"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange('lastName', e.target.value)}
                    placeholder="Doe"
                    className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
                  />
                </div>
              </div>

              <div>
                <Input
                  type="email"
                  label="Email Address"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="john@example.com"
                  required
                  className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
                />
              </div>

              <div>
                <Input
                  type="text"
                  label="Username"
                  value={formData.username}
                  onChange={(e) => handleInputChange('username', e.target.value)}
                  placeholder="johndoe"
                  required
                  helperText="This will be your public display name"
                  className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
                />
              </div>

              <div>
                <Input
                  type={showPassword ? 'text' : 'password'}
                  label="Password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  placeholder="Enter your password"
                  required
                  className="bg-dark-300/50 border-gray-700 text-white placeholder-gray-500 focus:border-neon-cyan"
                  error={passwordValidation.errors.length > 0 ? passwordValidation.errors[0] : undefined}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="mt-2 flex items-center space-x-1 text-sm text-gray-400 hover:text-neon-cyan transition-colors"
                >
                  {showPassword ? (
                    <EyeSlashIcon className="h-4 w-4" />
                  ) : (
                    <EyeIcon className="h-4 w-4" />
                  )}
                  <span>{showPassword ? 'Hide' : 'Show'} password</span>
                </button>

                {/* Password Requirements */}
                {formData.password && (
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center space-x-2 text-xs">
                      {passwordValidation.errors.length === 0 ? (
                        <CheckCircleIcon className="h-3 w-3 text-green-500" />
                      ) : (
                        <div className="h-3 w-3 rounded-full border border-gray-500" />
                      )}
                      <span className={passwordValidation.errors.length === 0 ? 'text-green-500' : 'text-gray-500'}>
                        {passwordValidation.errors.length === 0 ? 'Password meets all requirements' : 'Password requirements not met'}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="terms"
                  className="rounded border-gray-700 bg-dark-300/50 text-neon-cyan focus:ring-neon-cyan focus:ring-offset-dark-100"
                  required
                />
                <label htmlFor="terms" className="text-sm text-gray-400">
                  I agree to the{' '}
                  <Link href="/terms" className="text-neon-cyan hover:text-neon-purple">
                    Terms of Service
                  </Link>{' '}
                  and{' '}
                  <Link href="/privacy" className="text-neon-cyan hover:text-neon-purple">
                    Privacy Policy
                  </Link>
                </label>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading || !passwordValidation.isValid}
                size="lg"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Creating account...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <UserAddIcon className="h-5 w-5" />
                    <span>Create Account</span>
                  </div>
                )}
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-700" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-dark-200 text-gray-400">
                  Already have an account?
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <Link href="/auth/signin">
                <Button variant="outline" className="w-full">
                  <SparklesIcon className="h-5 w-5 mr-2" />
                  Sign in instead
                </Button>
              </Link>

              {/* Social signup options */}
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="ghost"
                  className="border-gray-700 hover:border-neon-cyan"
                  size="sm"
                >
                  Google
                </Button>
                <Button
                  variant="ghost"
                  className="border-gray-700 hover:border-neon-purple"
                  size="sm"
                >
                  GitHub
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-gray-500 mt-6">
          Join thousands of learners, creators, and high-achievers in the KRREVIVEÉLITE Universe.
        </p>
      </div>
    </div>
  );
}