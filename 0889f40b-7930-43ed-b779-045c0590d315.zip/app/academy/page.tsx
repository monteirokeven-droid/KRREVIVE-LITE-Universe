import React from 'react';
import { AcademyHero } from '@/components/academy/AcademyHero';
import { CourseGrid } from '@/components/academy/CourseGrid';
import { LearningPaths } from '@/components/academy/LearningPaths';
import { FeaturedInstructors } from '@/components/academy/FeaturedInstructors';
import { StudentSuccess } from '@/components/academy/StudentSuccess';

export default function AcademyPage() {
  return (
    <div className="space-y-8">
      <AcademyHero />
      <LearningPaths />
      <CourseGrid />
      <FeaturedInstructors />
      <StudentSuccess />
    </div>
  );
}