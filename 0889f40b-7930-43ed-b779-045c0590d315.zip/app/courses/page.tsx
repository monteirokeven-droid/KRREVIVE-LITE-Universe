import React from 'react';
import { CourseGrid } from '@/components/academy/CourseGrid';
import { CourseFilters } from '@/components/academy/CourseFilters';

export default function CoursesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-neon-purple">
            Course Library
          </h1>
          <p className="text-gray-400 mt-2">
            Explore our comprehensive collection of courses designed to transform your skills and accelerate your growth.
          </p>
        </div>
      </div>
      
      <CourseFilters />
      <CourseGrid />
    </div>
  );
}