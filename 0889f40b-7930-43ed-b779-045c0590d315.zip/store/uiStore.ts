import { create } from 'zustand';

interface UIState {
  sidebarOpen: boolean;
  darkMode: boolean;
  activeModule: string;
  notifications: any[];
  setSidebarOpen: (open: boolean) => void;
  setDarkMode: (dark: boolean) => void;
  setActiveModule: (module: string) => void;
  addNotification: (notification: any) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
}

export const useUIStore = create<UIState>((set, get) => ({
  sidebarOpen: false,
  darkMode: true,
  activeModule: 'dashboard',
  notifications: [],
  
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setDarkMode: (dark) => set({ darkMode: dark }),
  setActiveModule: (module) => set({ activeModule: module }),
  
  addNotification: (notification) => {
    const notifications = get().notifications;
    set({ notifications: [...notifications, { ...notification, id: Date.now() }] });
  },
  
  removeNotification: (id) => {
    const notifications = get().notifications.filter(n => n.id !== id);
    set({ notifications });
  },
  
  clearNotifications: () => set({ notifications: [] }),
}));