import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  user: any | null;
  isAuthenticated: boolean;
  subscription: 'free' | 'premium' | 'elite';
  credits: number;
  points: number;
  setUser: (user: any) => void;
  setAuthenticated: (isAuthenticated: boolean) => void;
  setSubscription: (tier: 'free' | 'premium' | 'elite') => void;
  addCredits: (amount: number) => void;
  addPoints: (amount: number) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      subscription: 'free',
      credits: 0,
      points: 0,
      
      setUser: (user) => set({ user }),
      setAuthenticated: (isAuthenticated) => set({ isAuthenticated }),
      setSubscription: (tier) => set({ subscription: tier }),
      
      addCredits: (amount) => {
        const currentCredits = get().credits;
        set({ credits: currentCredits + amount });
      },
      
      addPoints: (amount) => {
        const currentPoints = get().points;
        set({ points: currentPoints + amount });
      },
      
      logout: () => set({
        user: null,
        isAuthenticated: false,
        subscription: 'free',
        credits: 0,
        points: 0,
      }),
    }),
    {
      name: 'auth-storage',
    }
  )
);