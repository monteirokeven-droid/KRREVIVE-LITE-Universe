import { DefaultSession } from 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      username: string;
      role: string;
    } & DefaultSession['user'];
  }

  interface User {
    id: string;
    username: string;
    role: string;
  }
}

export interface User {
  id: string;
  email: string;
  username: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
  emailVerified: boolean;
  status: 'online' | 'offline' | 'grinding' | 'studying' | 'gaming';
  points: number;
  credits: number;
  streak: number;
  lastActiveAt?: Date;
  subscriptionTier: 'free' | 'premium' | 'elite';
  subscriptionEndsAt?: Date;
  stripeCustomerId?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserProfile {
  id: string;
  userId: string;
  bio?: string;
  interests?: string[];
  skills?: string[];
  socialLinks?: Record<string, string>;
  achievements?: string[];
  level: number;
  experience: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Product {
  id: string;
  name: string;
  description?: string;
  type: 'video' | 'ebook' | 'course' | 'tool' | 'template' | 'merch';
  price?: number;
  stripePriceId?: string;
  imageUrl?: string;
  fileUrl?: string;
  metadata?: Record<string, any>;
  isActive: boolean;
  creatorId?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor?: string;
  thumbnail?: string;
  price?: number;
  isPublished: boolean;
  category?: string;
  difficulty?: string;
  duration?: number;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CourseModule {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  videoUrl?: string;
  duration?: number;
  order: number;
  isPublished: boolean;
  createdAt: Date;
}

export interface Post {
  id: string;
  userId: string;
  content: string;
  imageUrl?: string;
  videoUrl?: string;
  likes: number;
  comments: number;
  shares: number;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
  user?: User;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  content: string;
  parentId?: string;
  likes: number;
  createdAt: Date;
  updatedAt: Date;
  user?: User;
  replies?: Comment[];
}

export interface Group {
  id: string;
  name: string;
  description?: string;
  category?: string;
  imageUrl?: string;
  isPrivate: boolean;
  memberCount: number;
  createdBy: string;
  createdAt: Date;
}

export interface DailyTask {
  id: string;
  userId: string;
  title: string;
  description?: string;
  completed: boolean;
  points: number;
  category?: string;
  dueDate?: Date;
  completedAt?: Date;
  createdAt: Date;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon?: string;
  points: number;
  category?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
}

export interface MediaLibrary {
  id: string;
  title: string;
  description?: string;
  type: 'video' | 'ebook' | 'course' | 'tool' | 'template' | 'merch';
  url: string;
  thumbnail?: string;
  tags?: string[];
  duration?: number;
  uploadedBy?: string;
  isPublic: boolean;
  viewCount: number;
  createdAt: Date;
}

export interface AutomationTool {
  id: string;
  name: string;
  description: string;
  type: string;
  config?: Record<string, any>;
  isPublic: boolean;
  createdBy?: string;
  usageCount: number;
  createdAt: Date;
}

export interface GamingSession {
  id: string;
  userId: string;
  game: string;
  score: number;
  duration: number;
  startedAt: Date;
  endedAt?: Date;
  metadata?: Record<string, any>;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  metadata?: Record<string, any>;
  createdAt: Date;
}

export interface ChatMessage {
  id: string;
  userId: string;
  room: string;
  message: string;
  type: 'text' | 'system' | 'image' | 'file';
  metadata?: Record<string, any>;
  createdAt: Date;
  user?: User;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  totalRevenue: number;
  monthlyRevenue: number;
  totalCourses: number;
  totalProducts: number;
  newUsersThisMonth: number;
}

export interface UserAnalytics {
  totalStudyTime: number;
  coursesCompleted: number;
  tasksCompleted: number;
  achievementsUnlocked: number;
  currentStreak: number;
  longestStreak: number;
  weeklyProgress: {
    day: string;
    studyTime: number;
    tasksCompleted: number;
  }[];
}

export interface RecommendationEngine {
  type: 'course' | 'tool' | 'content' | 'task' | 'goal';
  items: any[];
  reasoning: string;
}

export interface LearningPath {
  id: string;
  name: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  duration: number;
  courses: string[];
  milestones: {
    title: string;
    description: string;
    completed: boolean;
  }[];
  progress: number;
}

export interface LeaderboardEntry {
  userId: string;
  username: string;
  avatar?: string;
  score: number;
  rank: number;
  category: 'points' | 'streak' | 'courses' | 'gaming';
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  interval: 'month' | 'year';
  features: string[];
  stripePriceId: string;
  isPopular?: boolean;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  category: 'purchase' | 'refund' | 'reward' | 'subscription' | 'gift';
  status: 'pending' | 'completed' | 'failed';
  createdAt: Date;
}