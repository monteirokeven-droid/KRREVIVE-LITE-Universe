import { Resend } from 'resend';
import { env } from './env.mjs';

const resend = new Resend(env.RESEND_API_KEY);

export async function sendVerificationEmail(email: string, token: string) {
  const verificationUrl = `${env.NEXT_PUBLIC_APP_URL}/auth/verify?token=${token}`;

  try {
    const { data, error } = await resend.emails.send({
      from: env.FROM_EMAIL,
      to: [email],
      subject: 'Verify your KRREVIVEÉLITE account',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #0a0a0f, #1a0b2e); padding: 40px; border-radius: 10px;">
            <h1 style="color: #00ffea; font-size: 28px; margin-bottom: 20px;">KRREVIVEÉLITE Universe</h1>
            <h2 style="color: #ffffff; font-size: 24px; margin-bottom: 20px;">Verify Your Email</h2>
            <p style="color: #b0b0b0; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
              Thank you for joining KRREVIVEÉLITE! Please click the button below to verify your email address and activate your account.
            </p>
            <div style="text-align: center; margin-bottom: 30px;">
              <a href="${verificationUrl}" 
                 style="background: linear-gradient(45deg, #00ffea, #ff00ff); 
                        color: #000; 
                        padding: 15px 30px; 
                        text-decoration: none; 
                        border-radius: 8px; 
                        font-weight: bold;
                        display: inline-block;
                        box-shadow: 0 4px 15px rgba(0, 255, 234, 0.3);">
                Verify Email
              </a>
            </div>
            <p style="color: #808080; font-size: 14px; margin-bottom: 20px;">
              Or copy and paste this link into your browser:<br>
              <span style="color: #00ffea;">${verificationUrl}</span>
            </p>
            <p style="color: #808080; font-size: 12px;">
              This link expires in 24 hours. If you didn't request this verification, please ignore this email.
            </p>
          </div>
        </div>
      `,
    });

    if (error) {
      console.error('Error sending verification email:', error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error('Error sending verification email:', error);
    return { success: false, error };
  }
}

export async function sendPasswordResetEmail(email: string, token: string) {
  const resetUrl = `${env.NEXT_PUBLIC_APP_URL}/auth/reset-password?token=${token}`;

  try {
    const { data, error } = await resend.emails.send({
      from: env.FROM_EMAIL,
      to: [email],
      subject: 'Reset your KRREVIVEÉLITE password',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #0a0a0f, #1a0b2e); padding: 40px; border-radius: 10px;">
            <h1 style="color: #00ffea; font-size: 28px; margin-bottom: 20px;">KRREVIVEÉLITE Universe</h1>
            <h2 style="color: #ffffff; font-size: 24px; margin-bottom: 20px;">Reset Your Password</h2>
            <p style="color: #b0b0b0; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
              We received a request to reset your password. Click the button below to create a new password.
            </p>
            <div style="text-align: center; margin-bottom: 30px;">
              <a href="${resetUrl}" 
                 style="background: linear-gradient(45deg, #ff0055, #ff00ff); 
                        color: #fff; 
                        padding: 15px 30px; 
                        text-decoration: none; 
                        border-radius: 8px; 
                        font-weight: bold;
                        display: inline-block;
                        box-shadow: 0 4px 15px rgba(255, 0, 85, 0.3);">
                Reset Password
              </a>
            </div>
            <p style="color: #808080; font-size: 14px; margin-bottom: 20px;">
              Or copy and paste this link into your browser:<br>
              <span style="color: #00ffea;">${resetUrl}</span>
            </p>
            <p style="color: #808080; font-size: 12px;">
              This link expires in 1 hour. If you didn't request this reset, please ignore this email.
            </p>
          </div>
        </div>
      `,
    });

    if (error) {
      console.error('Error sending password reset email:', error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return { success: false, error };
  }
}

export async function sendWelcomeEmail(email: string, username: string) {
  try {
    const { data, error } = await resend.emails.send({
      from: env.FROM_EMAIL,
      to: [email],
      subject: 'Welcome to KRREVIVEÉLITE Universe',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #0a0a0f, #1a0b2e); padding: 40px; border-radius: 10px;">
            <h1 style="color: #00ffea; font-size: 28px; margin-bottom: 20px;">KRREVIVEÉLITE Universe</h1>
            <h2 style="color: #ffffff; font-size: 24px; margin-bottom: 20px;">Welcome, ${username}!</h2>
            <p style="color: #b0b0b0; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
              You're now part of an exclusive community of high-achievers, gamers, and knowledge seekers. Your journey to excellence begins now!
            </p>
            <div style="background: rgba(0, 255, 234, 0.1); padding: 20px; border-radius: 8px; margin-bottom: 30px;">
              <h3 style="color: #00ffea; margin-bottom: 15px;">What's Next?</h3>
              <ul style="color: #ffffff; line-height: 1.8;">
                <li>Complete your profile to unlock personalized recommendations</li>
                <li>Start your first daily task to earn points</li>
                <li>Explore our course library and tools</li>
                <li>Join the community chat rooms</li>
                <li>Upgrade to Premium for exclusive features</li>
              </ul>
            </div>
            <div style="text-align: center; margin-bottom: 30px;">
              <a href="${env.NEXT_PUBLIC_APP_URL}/dashboard" 
                 style="background: linear-gradient(45deg, #00ffea, #ff00ff); 
                        color: #000; 
                        padding: 15px 30px; 
                        text-decoration: none; 
                        border-radius: 8px; 
                        font-weight: bold;
                        display: inline-block;
                        box-shadow: 0 4px 15px rgba(0, 255, 234, 0.3);">
                Go to Dashboard
              </a>
            </div>
            <p style="color: #808080; font-size: 12px;">
              If you have any questions, reply to this email or visit our help center.
            </p>
          </div>
        </div>
      `,
    });

    if (error) {
      console.error('Error sending welcome email:', error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error('Error sending welcome email:', error);
    return { success: false, error };
  }
}