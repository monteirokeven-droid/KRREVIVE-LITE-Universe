import { pgTable, text, timestamp, boolean, integer, json, uuid, pgEnum, decimal } from 'drizzle-orm/pg-core';

// Enums
export const subscriptionTierEnum = pgEnum('subscription_tier', ['free', 'premium', 'elite']);
export const userStatusEnum = pgEnum('user_status', ['online', 'offline', 'grinding', 'studying', 'gaming']);
export const contentTypeEnum = pgEnum('content_type', ['video', 'ebook', 'course', 'tool', 'template', 'merch']);

// Users Table
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: text('email').unique().notNull(),
  username: text('username').unique().notNull(),
  password: text('password').notNull(),
  firstName: text('first_name'),
  lastName: text('last_name'),
  avatar: text('avatar'),
  emailVerified: boolean('email_verified').default(false),
  status: userStatusEnum('status').default('offline'),
  points: integer('points').default(0),
  credits: decimal('credits', { precision: 10, scale: 2 }).default('0'),
  streak: integer('streak').default(0),
  lastActiveAt: timestamp('last_active_at'),
  subscriptionTier: subscriptionTierEnum('subscription_tier').default('free'),
  subscriptionEndsAt: timestamp('subscription_ends_at'),
  stripeCustomerId: text('stripe_customer_id'),
  metadata: json('metadata').$type(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// User Profiles
export const userProfiles = pgTable('user_profiles', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  bio: text('bio'),
  interests: json('interests').$type(),
  skills: json('skills').$type(),
  socialLinks: json('social_links').$type(),
  achievements: json('achievements').$type(),
  level: integer('level').default(1),
  experience: integer('experience').default(0),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Subscriptions
export const subscriptions = pgTable('subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  tier: subscriptionTierEnum('tier').notNull(),
  stripeSubscriptionId: text('stripe_subscription_id'),
  status: text('status'),
  currentPeriodStart: timestamp('current_period_start'),
  currentPeriodEnd: timestamp('current_period_end'),
  cancelAtPeriodEnd: boolean('cancel_at_period_end').default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Products
export const products = pgTable('products', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  description: text('description'),
  type: contentTypeEnum('type').notNull(),
  price: decimal('price', { precision: 10, scale: 2 }),
  stripePriceId: text('stripe_price_id'),
  imageUrl: text('image_url'),
  fileUrl: text('file_url'),
  metadata: json('metadata').$type(),
  isActive: boolean('is_active').default(true),
  creatorId: uuid('creator_id').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Purchases
export const purchases = pgTable('purchases', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  productId: uuid('product_id').references(() => products.id).notNull(),
  stripePaymentId: text('stripe_payment_id'),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  status: text('status').notNull(),
  licenseKey: text('license_key'),
  downloadCount: integer('download_count').default(0),
  createdAt: timestamp('created_at').defaultNow(),
});

// Courses
export const courses = pgTable('courses', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: text('title').notNull(),
  description: text('description'),
  instructor: text('instructor'),
  thumbnail: text('thumbnail'),
  price: decimal('price', { precision: 10, scale: 2 }),
  isPublished: boolean('is_published').default(false),
  category: text('category'),
  difficulty: text('difficulty'),
  duration: integer('duration'), // in minutes
  metadata: json('metadata').$type(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Course Modules
export const courseModules = pgTable('course_modules', {
  id: uuid('id').primaryKey().defaultRandom(),
  courseId: uuid('course_id').references(() => courses.id).notNull(),
  title: text('title').notNull(),
  description: text('description'),
  videoUrl: text('video_url'),
  duration: integer('duration'),
  order: integer('order'),
  isPublished: boolean('is_published').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// User Progress
export const userProgress = pgTable('user_progress', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  courseId: uuid('course_id').references(() => courses.id).notNull(),
  moduleId: uuid('module_id').references(() => courseModules.id),
  completed: boolean('completed').default(false),
  timeSpent: integer('time_spent').default(0),
  lastAccessedAt: timestamp('last_accessed_at'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Social Posts
export const posts = pgTable('posts', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  content: text('content').notNull(),
  imageUrl: text('image_url'),
  videoUrl: text('video_url'),
  likes: integer('likes').default(0),
  comments: integer('comments').default(0),
  shares: integer('shares').default(0),
  metadata: json('metadata').$type(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Comments
export const comments = pgTable('comments', {
  id: uuid('id').primaryKey().defaultRandom(),
  postId: uuid('post_id').references(() => posts.id).notNull(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  content: text('content').notNull(),
  parentId: uuid('parent_id').references(() => comments.id),
  likes: integer('likes').default(0),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Groups
export const groups = pgTable('groups', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  description: text('description'),
  category: text('category'),
  imageUrl: text('image_url'),
  isPrivate: boolean('is_private').default(false),
  memberCount: integer('member_count').default(0),
  createdBy: uuid('created_by').references(() => users.id).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Group Members
export const groupMembers = pgTable('group_members', {
  id: uuid('id').primaryKey().defaultRandom(),
  groupId: uuid('group_id').references(() => groups.id).notNull(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  role: text('role').default('member'),
  joinedAt: timestamp('joined_at').defaultNow(),
});

// Daily Tasks
export const dailyTasks = pgTable('daily_tasks', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  title: text('title').notNull(),
  description: text('description'),
  completed: boolean('completed').default(false),
  points: integer('points').default(10),
  category: text('category'),
  dueDate: timestamp('due_date'),
  completedAt: timestamp('completed_at'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Achievements
export const achievements = pgTable('achievements', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  description: text('description'),
  icon: text('icon'),
  points: integer('points').default(50),
  category: text('category'),
  metadata: json('metadata').$type(),
  createdAt: timestamp('created_at').defaultNow(),
});

// User Achievements
export const userAchievements = pgTable('user_achievements', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  achievementId: uuid('achievement_id').references(() => achievements.id).notNull(),
  unlockedAt: timestamp('unlocked_at').defaultNow(),
});

// Gaming Sessions
export const gamingSessions = pgTable('gaming_sessions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  game: text('game').notNull(),
  score: integer('score').default(0),
  duration: integer('duration'),
  startedAt: timestamp('started_at').defaultNow(),
  endedAt: timestamp('ended_at'),
  metadata: json('metadata').$type(),
});

// Media Library
export const mediaLibrary = pgTable('media_library', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: text('title').notNull(),
  description: text('description'),
  type: contentTypeEnum('type').notNull(),
  url: text('url').notNull(),
  thumbnail: text('thumbnail'),
  tags: json('tags').$type(),
  duration: integer('duration'),
  uploadedBy: uuid('uploaded_by').references(() => users.id),
  isPublic: boolean('is_public').default(true),
  viewCount: integer('view_count').default(0),
  createdAt: timestamp('created_at').defaultNow(),
});

// Automation Tools
export const automationTools = pgTable('automation_tools', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  description: text('description'),
  type: text('type').notNull(),
  config: json('config').$type(),
  isPublic: boolean('is_public').default(true),
  createdBy: uuid('created_by').references(() => users.id),
  usageCount: integer('usage_count').default(0),
  createdAt: timestamp('created_at').defaultNow(),
});

// User Tool Usage
export const userToolUsage = pgTable('user_tool_usage', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  toolId: uuid('tool_id').references(() => automationTools.id).notNull(),
  usageCount: integer('usage_count').default(0),
  lastUsedAt: timestamp('last_used_at').defaultNow(),
});

// Notifications
export const notifications = pgTable('notifications', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  title: text('title').notNull(),
  message: text('message').notNull(),
  type: text('type').notNull(),
  read: boolean('read').default(false),
  metadata: json('metadata').$type(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Chat Messages
export const chatMessages = pgTable('chat_messages', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id).notNull(),
  room: text('room').notNull(),
  message: text('message').notNull(),
  type: text('type').default('text'),
  metadata: json('metadata').$type(),
  createdAt: timestamp('created_at').defaultNow(),
});