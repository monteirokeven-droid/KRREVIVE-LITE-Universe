import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, formatDistanceToNow } from 'date-fns';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function formatDate(date: Date | string): string {
  return format(new Date(date), 'MMM dd, yyyy');
}

export function formatTimeAgo(date: Date | string): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true });
}

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).trim() + '...';
}

export function generateId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

export function calculateLevel(experience: number): number {
  return Math.floor(Math.sqrt(experience / 100)) + 1;
}

export function calculateExperienceForLevel(level: number): number {
  return Math.pow(level - 1, 2) * 100;
}

export function getProgressToNextLevel(currentExperience: number): {
  current: number;
  next: number;
  progress: number;
} {
  const currentLevel = calculateLevel(currentExperience);
  const currentLevelXP = calculateExperienceForLevel(currentLevel);
  const nextLevelXP = calculateExperienceForLevel(currentLevel + 1);
  const progress = ((currentExperience - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;

  return {
    current: currentLevelXP,
    next: nextLevelXP,
    progress: Math.round(progress),
  };
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePassword(password: string): {
  isValid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }

  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }

  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }

  if (!/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

export function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  if (hours > 0) {
    return `${hours}h ${minutes}m ${remainingSeconds}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${remainingSeconds}s`;
  } else {
    return `${remainingSeconds}s`;
  }
}

export function getUserStatusColor(status: string): string {
  const statusColors: Record<string, string> = {
    online: '#00ff88',
    offline: '#666666',
    grinding: '#ff0055',
    studying: '#00ffea',
    gaming: '#ff00ff',
  };
  return statusColors[status] || '#666666';
}

export function getSubscriptionColor(tier: string): string {
  const tierColors: Record<string, string> = {
    free: '#808080',
    premium: '#00ffea',
    elite: '#ff00ff',
  };
  return tierColors[tier] || '#808080';
}

export function getDifficultyColor(difficulty: string): string {
  const difficultyColors: Record<string, string> = {
    beginner: '#00ff88',
    intermediate: '#ffdd00',
    advanced: '#ff0055',
    expert: '#ff00ff',
  };
  return difficultyColors[difficulty] || '#808080';
}

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

export function copyToClipboard(text: string): Promise<void> {
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(text);
  } else {
    // Fallback for older browsers
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    return new Promise((resolve, reject) => {
      document.execCommand('copy') ? resolve() : reject();
      textArea.remove();
    });
  }
}

export function downloadFile(data: string, filename: string, type: string): void {
  const blob = new Blob([data], { type });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
}

export function generateAvatarUrl(seed: string, size: number = 200): string {
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}&size=${size}`;
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(word => word.charAt(0))
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

export function sanitizeHtml(html: string): string {
  // Basic HTML sanitization - in production, use a library like DOMPurify
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/on\w+="[^"]*"/gi, '')
    .replace(/javascript:/gi, '');
}

export function generateProgressBar(percentage: number, size: 'sm' | 'md' | 'lg' = 'md'): string {
  const sizes = {
    sm: 'h-2',
    md: 'h-3',
    lg: 'h-4',
  };

  const colors = percentage >= 75 ? 'bg-neon-green' : 
                 percentage >= 50 ? 'bg-neon-cyan' : 
                 percentage >= 25 ? 'bg-yellow-500' : 'bg-red-500';

  return `
    <div class="w-full bg-gray-700 rounded-full ${sizes[size]}">
      <div 
        class="${colors} ${sizes[size]} rounded-full transition-all duration-300"
        style="width: ${percentage}%"
      ></div>
    </div>
  `;
}