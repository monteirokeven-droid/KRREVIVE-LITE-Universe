import OpenAI from 'openai';
import { env } from './env.mjs';

const openai = new OpenAI({
  apiKey: env.OPENAI_API_KEY,
});

export async function generateTaskRecommendations(userProfile: any) {
  const prompt = `
    Based on the following user profile, generate 5 personalized daily tasks that align with their goals and interests:
    
    User Profile:
    - Status: ${userProfile.status}
    - Interests: ${userProfile.interests?.join(', ') || 'Not specified'}
    - Skills: ${userProfile.skills?.join(', ') || 'Not specified'}
    - Current Level: ${userProfile.level}
    - Subscription Tier: ${userProfile.subscriptionTier}
    
    Generate tasks that:
    1. Help them level up and gain experience
    2. Align with their interests and current status
    3. Are achievable within 24 hours
    4. Include a mix of learning, productivity, and wellness activities
    5. Award appropriate points (10-50 points per task)
    
    Return as JSON array with format: [{title, description, points, category, difficulty}]
  `;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are an AI assistant for KRREVIVEÉLITE Universe, specializing in personal development and productivity optimization.'
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    const content = response.choices[0]?.message?.content;
    if (content) {
      return JSON.parse(content);
    }
    return [];
  } catch (error) {
    console.error('Error generating task recommendations:', error);
    return [];
  }
}

export async function generateContentRecommendations(userProfile: any) {
  const prompt = `
    Based on the following user profile, recommend 8 pieces of content (courses, videos, books, or tools) that would be most valuable:
    
    User Profile:
    - Status: ${userProfile.status}
    - Interests: ${userProfile.interests?.join(', ') || 'Not specified'}
    - Skills: ${userProfile.skills?.join(', ') || 'Not specified'}
    - Current Level: ${userProfile.level}
    - Subscription Tier: ${userProfile.subscriptionTier}
    
    Recommend a mix of:
    - 2 courses
    - 2 videos
    - 2 books
    - 2 tools
    
    Return as JSON array with format: [{title, type, description, difficulty, estimatedTime, points, category}]
  `;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are a content curator for KRREVIVEÉLITE Universe, specializing in personal development, gaming, and productivity content.'
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    const content = response.choices[0]?.message?.content;
    if (content) {
      return JSON.parse(content);
    }
    return [];
  } catch (error) {
    console.error('Error generating content recommendations:', error);
    return [];
  }
}

export async function generateAIResponse(message: string, context: any) {
  const prompt = `
    You are an AI assistant for KRREVIVEÉLITE Universe. Respond to the user's message with helpful, inspiring, and actionable advice.
    
    User Context:
    - Status: ${context.status}
    - Level: ${context.level}
    - Current Goals: ${context.goals?.join(', ') || 'Not specified'}
    
    User Message: ${message}
    
    Provide a response that:
    1. Is encouraging and motivational
    2. Offers practical advice or solutions
    3. Aligns with the KRREVIVEÉLITE brand (futuristic, spiritual-awakened, high-performance)
    4. Includes specific action items when appropriate
    5. Is conversational and engaging
    
    Keep responses concise but impactful (under 200 words).
  `;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are a wise AI assistant for KRREVIVEÉLITE Universe, combining technology insights with spiritual wisdom and peak performance strategies.'
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 300,
    });

    return response.choices[0]?.message?.content || 'I apologize, but I cannot provide a response at this moment.';
  } catch (error) {
    console.error('Error generating AI response:', error);
    return 'I apologize, but I encountered an error. Please try again later.';
  }
}

export async function generateWritingPrompt(topic: string, style: string) {
  const prompt = `
    Generate a creative writing prompt based on:
    - Topic: ${topic}
    - Style: ${style}
    
    Create an engaging prompt that inspires high-quality content creation. Include:
    - A compelling title suggestion
    - Key points to cover
    - Tone and style guidelines
    - Target audience considerations
    
    Return as JSON with format: {title, prompt, keyPoints, tone, audience, wordCount}
  `;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are a creative writing assistant for KRREVIVEÉLITE Universe, specializing in generating compelling content ideas.'
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.8,
      max_tokens: 500,
    });

    const content = response.choices[0]?.message?.content;
    if (content) {
      return JSON.parse(content);
    }
    return null;
  } catch (error) {
    console.error('Error generating writing prompt:', error);
    return null;
  }
}

export async function generateSocialMediaPost(content: string, platform: string) {
  const prompt = `
    Create an engaging social media post for ${platform} based on this content: "${content}"
    
    For ${platform}, create a post that:
    - Captures attention immediately
    - Uses platform-appropriate formatting
    - Includes relevant hashtags
    - Has a clear call-to-action
    - Optimizes for the platform's character limits and best practices
    
    Return as JSON with format: {content, hashtags, callToAction, emojiUsage}
  `;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are a social media expert for KRREVIVEÉLITE Universe, creating viral content across all platforms.'
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 400,
    });

    const content = response.choices[0]?.message?.content;
    if (content) {
      return JSON.parse(content);
    }
    return null;
  } catch (error) {
    console.error('Error generating social media post:', error);
    return null;
  }
}

export async function generateWeeklyGoals(userProfile: any) {
  const prompt = `
    Based on this user profile, generate 5 meaningful weekly goals that balance growth, wellness, and productivity:
    
    User Profile:
    - Level: ${userProfile.level}
    - Status: ${userProfile.status}
    - Interests: ${userProfile.interests?.join(', ') || 'General'}
    - Current Skills: ${userProfile.skills?.join(', ') || 'Not specified'}
    - Subscription Tier: ${userProfile.subscriptionTier}
    
    Create goals that:
    1. Are challenging but achievable in one week
    2. Align with their current level and interests
    3. Include different life areas (personal, professional, health, learning)
    4. Have measurable outcomes
    5. Award significant experience points when completed
    
    Return as JSON array with format: [{title, description, category, difficulty, xpReward, dailyMilestones}]
  `;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are a personal development coach for KRREVIVEÉLITE Universe, specializing in goal setting and achievement.'
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 800,
    });

    const content = response.choices[0]?.message?.content;
    if (content) {
      return JSON.parse(content);
    }
    return [];
  } catch (error) {
    console.error('Error generating weekly goals:', error);
    return [];
  }
}