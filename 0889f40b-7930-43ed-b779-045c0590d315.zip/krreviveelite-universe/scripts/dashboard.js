// KRREVIVEÉLITE Dashboard JavaScript
// Main dashboard functionality and utilities

class KRREVIVEDashboard {
    constructor() {
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.loadUserStats();
        this.initializeNotifications();
        this.startRealTimeUpdates();
    }
    
    setupEventListeners() {
        // Premium buttons
        document.querySelectorAll('.premium-lock').forEach(btn => {
            btn.addEventListener('click', () => this.showSubscriptionModal());
        });
        
        // Tool cards
        document.querySelectorAll('.card').forEach(card => {
            card.addEventListener('mouseenter', () => this.addHoverEffect(card));
            card.addEventListener('mouseleave', () => this.removeHoverEffect(card));
        });
        
        // Quick action buttons
        document.querySelectorAll('.task-item button').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleTaskAction(e));
        });
    }
    
    loadUserStats() {
        // Simulate loading user statistics
        const stats = {
            toolsUsed: 12,
            tasksCompleted: 28,
            premiumFeatures: 5,
            timeSaved: '4.5 hours'
        };
        
        // Update dashboard stats if elements exist
        Object.keys(stats).forEach(key => {
            const element = document.getElementById(key);
            if (element) {
                element.textContent = stats[key];
            }
        });
    }
    
    initializeNotifications() {
        // Sample notifications system
        const notifications = [
            {
                type: 'success',
                message: 'Your resume has been generated successfully!',
                timestamp: new Date(Date.now() - 300000)
            },
            {
                type: 'info',
                message: 'New automation scripts available in Engineering Hub',
                timestamp: new Date(Date.now() - 600000)
            },
            {
                type: 'warning',
                message: 'Premium subscription expires in 3 days',
                timestamp: new Date(Date.now() - 900000)
            }
        ];
        
        this.displayNotifications(notifications);
    }
    
    displayNotifications(notifications) {
        const container = document.querySelector('.notifications .grid');
        if (!container) return;
        
        notifications.forEach(notification => {
            const notificationEl = document.createElement('div');
            notificationEl.className = 'notification-item';
            notificationEl.innerHTML = `
                <i class="fas fa-${this.getNotificationIcon(notification.type)}" 
                   style="color: ${this.getNotificationColor(notification.type)};"></i>
                <strong>${notification.message}</strong>
                <small>${this.formatTimestamp(notification.timestamp)}</small>
            `;
            container.appendChild(notificationEl);
        });
    }
    
    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            info: 'info-circle',
            warning: 'exclamation-triangle',
            error: 'times-circle'
        };
        return icons[type] || 'info-circle';
    }
    
    getNotificationColor(type) {
        const colors = {
            success: 'var(--neon-green)',
            info: 'var(--neon-cyan)',
            warning: 'var(--neon-yellow)',
            error: 'var(--neon-pink)'
        };
        return colors[type] || 'var(--neon-cyan)';
    }
    
    formatTimestamp(timestamp) {
        const now = new Date();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 60000);
        
        if (minutes < 60) {
            return `${minutes} minutes ago`;
        } else {
            const hours = Math.floor(minutes / 60);
            return `${hours} hours ago`;
        }
    }
    
    startRealTimeUpdates() {
        // Update timestamps and dynamic content every minute
        setInterval(() => {
            this.updateDynamicContent();
        }, 60000);
    }
    
    updateDynamicContent() {
        // Update any time-sensitive content
        const timestamps = document.querySelectorAll('.timestamp');
        timestamps.forEach(el => {
            const timestamp = new Date(el.dataset.timestamp);
            el.textContent = this.formatTimestamp(timestamp);
        });
    }
    
    addHoverEffect(element) {
        element.style.transform = 'translateY(-5px) scale(1.02)';
        element.style.boxShadow = '0 0 30px rgba(0, 255, 234, 0.5)';
    }
    
    removeHoverEffect(element) {
        element.style.transform = '';
        element.style.boxShadow = '';
    }
    
    handleTaskAction(event) {
        const button = event.target.closest('button');
        const originalContent = button.innerHTML;
        
        // Show loading state
        button.innerHTML = '<span class="loading"></span> Processing...';
        button.disabled = true;
        
        // Simulate task execution
        setTimeout(() => {
            button.innerHTML = '<i class="fas fa-check"></i> Completed';
            
            setTimeout(() => {
                button.innerHTML = originalContent;
                button.disabled = false;
            }, 2000);
        }, 1500);
    }
    
    showSubscriptionModal() {
        const modal = document.getElementById('subscriptionModal');
        if (modal) {
            modal.classList.add('active');
        }
    }
    
    trackUserAction(action, details = {}) {
        // Analytics tracking
        console.log('User action tracked:', action, details);
        
        // In production, this would send to analytics service
        if (typeof gtag !== 'undefined') {
            gtag('event', action, details);
        }
    }
    
    showPremiumUpgrade(feature) {
        this.trackUserAction('premium_upgrade_attempt', { feature });
        this.showSubscriptionModal();
    }
}

// Initialize dashboard when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new KRREVIVEDashboard();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = KRREVIVEDashboard;
}