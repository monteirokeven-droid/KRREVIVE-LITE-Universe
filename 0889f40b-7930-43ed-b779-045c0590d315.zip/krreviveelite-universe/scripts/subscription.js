// KRREVIVEÉLITE Subscription Management System
// Handles payments, premium unlocks, and user authentication

class SubscriptionManager {
    constructor() {
        this.user = null;
        this.isPremium = false;
        this.subscription = null;
        this.init();
    }
    
    init() {
        this.loadUserData();
        this.setupSubscriptionModals();
        this.setupPaymentHandlers();
        this.setupPremiumGating();
        this.initializeAIUnlocks();
    }
    
    loadUserData() {
        // Load user data from localStorage or API
        const savedUser = localStorage.getItem('krrevive_user');
        if (savedUser) {
            this.user = JSON.parse(savedUser);
            this.isPremium = this.user.isPremium || false;
            this.subscription = this.user.subscription || null;
            this.updateUIForUser();
        }
    }
    
    setupSubscriptionModals() {
        // Create subscription modal if it doesn't exist
        if (!document.getElementById('subscriptionModal')) {
            this.createSubscriptionModal();
        }
        
        // Setup modal triggers
        document.querySelectorAll('.btn-premium, .premium-lock').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showSubscriptionModal();
            });
        });
        
        // Setup close button
        const closeBtn = document.querySelector('.modal-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeSubscriptionModal());
        }
    }
    
    createSubscriptionModal() {
        const modal = document.createElement('div');
        modal.id = 'subscriptionModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <button class="modal-close">&times;</button>
                <h2 style="color: #FFD700; text-align: center;">
                    <i class="fas fa-crown"></i> Unlock Premium Features
                </h2>
                <p style="text-align: center; margin-bottom: 2rem;">Get unlimited access to all tools, templates, and AI-powered features.</p>
                
                <div class="pricing-plans">
                    <div class="plan-card" style="border: 1px solid var(--neon-cyan); padding: 1.5rem; margin-bottom: 1rem; border-radius: 10px;">
                        <h3 style="color: var(--neon-cyan);">Monthly</h3>
                        <div style="font-size: 2rem; font-weight: bold; color: var(--text-primary);">$9.99<span style="font-size: 1rem; color: var(--text-muted);">/month</span></div>
                        <ul style="list-style: none; margin: 1rem 0;">
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> All Premium Features</li>
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> AI Assistance</li>
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> Unlimited Templates</li>
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> Priority Support</li>
                        </ul>
                        <button class="btn btn-primary" style="width: 100%;" onclick="subscriptionManager.processPayment('monthly')">
                            <i class="fab fa-stripe"></i> Subscribe with Stripe
                        </button>
                    </div>
                    
                    <div class="plan-card" style="border: 2px solid #FFD700; padding: 1.5rem; border-radius: 10px; background: rgba(255, 215, 0, 0.1);">
                        <h3 style="color: #FFD700;">Yearly <span style="background: #FFD700; color: var(--primary-dark); padding: 0.2rem 0.5rem; border-radius: 20px; font-size: 0.8rem;">SAVE 20%</span></h3>
                        <div style="font-size: 2rem; font-weight: bold; color: var(--text-primary);">$95.99<span style="font-size: 1rem; color: var(--text-muted);">/year</span></div>
                        <ul style="list-style: none; margin: 1rem 0;">
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> Everything in Monthly</li>
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> Exclusive Templates</li>
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> Advanced AI Features</li>
                            <li><i class="fas fa-check" style="color: var(--neon-green);"></i> VIP Support</li>
                        </ul>
                        <button class="btn btn-premium" style="width: 100%;" onclick="subscriptionManager.processPayment('yearly')">
                            <i class="fab fa-stripe"></i> Subscribe with Stripe
                        </button>
                        <button class="btn btn-secondary" style="width: 100%; margin-top: 0.5rem;" onclick="subscriptionManager.processPaymentPaypal('yearly')">
                            <i class="fab fa-paypal"></i> Pay with PayPal
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    setupPaymentHandlers() {
        // Stripe payment processing
        this.stripeHandler = Stripe('pk_test_placeholder'); // Replace with actual Stripe key
        
        // PayPal payment processing
        this.paypalHandler = {
            createOrder: (data, actions) => {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: '9.99'
                        }
                    }]
                });
            },
            onApprove: (data, actions) => {
                return actions.order.capture().then(details => {
                    this.handlePaymentSuccess('paypal', details);
                });
            }
        };
    }
    
    setupPremiumGating() {
        // Add click handlers to all premium-gated content
        document.querySelectorAll('[data-premium="true"]').forEach(element => {
            element.addEventListener('click', (e) => {
                if (!this.isPremium) {
                    e.preventDefault();
                    e.stopPropagation();
                    this.showPremiumUpgradeDialog();
                }
            });
        });
        
        // Update UI based on subscription status
        this.updatePremiumUI();
    }
    
    initializeAIUnlocks() {
        // Setup AI unlock buttons
        document.querySelectorAll('[data-ai-feature]').forEach(button => {
            button.addEventListener('click', (e) => {
                const feature = e.target.dataset.aiFeature;
                this.handleAIFeatureRequest(feature);
            });
        });
    }
    
    showSubscriptionModal() {
        const modal = document.getElementById('subscriptionModal');
        if (modal) {
            modal.classList.add('active');
            this.trackEvent('subscription_modal_shown');
        }
    }
    
    closeSubscriptionModal() {
        const modal = document.getElementById('subscriptionModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }
    
    async processPayment(plan) {
        try {
            this.showLoading('Processing payment...');
            
            // In production, this would integrate with actual Stripe
            const paymentData = {
                plan: plan,
                amount: plan === 'monthly' ? 9.99 : 95.99,
                currency: 'USD'
            };
            
            // Simulate payment processing
            await this.simulatePayment(paymentData);
            
            this.handlePaymentSuccess('stripe', paymentData);
            
        } catch (error) {
            this.handlePaymentError(error);
        }
    }
    
    async processPaymentPaypal(plan) {
        try {
            this.showLoading('Redirecting to PayPal...');
            
            // In production, this would integrate with actual PayPal
            const paymentData = {
                plan: plan,
                amount: plan === 'monthly' ? 9.99 : 95.99,
                currency: 'USD'
            };
            
            // Simulate PayPal redirect
            setTimeout(() => {
                this.handlePaymentSuccess('paypal', paymentData);
            }, 2000);
            
        } catch (error) {
            this.handlePaymentError(error);
        }
    }
    
    handlePaymentSuccess(provider, paymentData) {
        // Update user subscription
        this.user = {
            ...this.user,
            isPremium: true,
            subscription: {
                provider: provider,
                plan: paymentData.plan,
                amount: paymentData.amount,
                startDate: new Date().toISOString(),
                endDate: new Date(Date.now() + (paymentData.plan === 'monthly' ? 30 : 365) * 24 * 60 * 60 * 1000).toISOString()
            }
        };
        
        this.saveUserData();
        this.isPremium = true;
        this.updateUIForUser();
        this.closeSubscriptionModal();
        
        this.showSuccess('Payment successful! Welcome to Premium!');
        this.trackEvent('subscription_completed', paymentData);
        
        // Unlock all premium features
        this.unlockPremiumFeatures();
    }
    
    handlePaymentError(error) {
        this.showError('Payment failed. Please try again.');
        this.trackEvent('payment_failed', { error: error.message });
    }
    
    showPremiumUpgradeDialog() {
        const feature = event.target.closest('[data-feature]')?.dataset.feature || 'this feature';
        this.showNotification(`${feature} requires a premium subscription. Upgrade now to unlock all features!`, 'warning');
        setTimeout(() => this.showSubscriptionModal(), 1000);
    }
    
    handleAIFeatureRequest(feature) {
        if (!this.isPremium) {
            this.showNotification('AI features require a premium subscription. Upgrade now to unlock AI assistance!', 'warning');
            this.showSubscriptionModal();
            return;
        }
        
        // Execute AI feature
        this.executeAIFeature(feature);
    }
    
    executeAIFeature(feature) {
        const aiFeatures = {
            'resume-suggestion': () => this.generateResumeSuggestion(),
            'code-suggestion': () => this.generateCodeSuggestion(),
            'automation-script': () => this.generateAutomationScript(),
            'content-recommendation': () => this.getContentRecommendation()
        };
        
        if (aiFeatures[feature]) {
            aiFeatures[feature]();
        }
    }
    
    generateResumeSuggestion() {
        this.showNotification('AI is analyzing your resume...', 'info');
        setTimeout(() => {
            const suggestion = "Consider adding quantifiable achievements to your experience section. For example: 'Increased team productivity by 35% through implementing agile methodologies.'";
            this.insertSuggestion(suggestion);
        }, 2000);
    }
    
    generateCodeSuggestion() {
        this.showNotification('AI is analyzing your code...', 'info');
        setTimeout(() => {
            const suggestion = "// Consider adding error handling\ntry {\n  // Your code here\n} catch (error) {\n  console.error('Error:', error);\n  // Handle error appropriately\n}";
            this.insertSuggestion(suggestion);
        }, 2000);
    }
    
    generateAutomationScript() {
        this.showNotification('AI is generating automation script...', 'info');
        setTimeout(() => {
            const script = `#!/usr/bin/env python3\n# AI-Generated Automation Script\nimport time\nimport schedule\n\ndef automated_task():\n    """Execute automated task"""\n    print(f"Running automated task at {time.ctime()}")\n    # Add your automation logic here\n    pass\n\n# Schedule the task\nschedule.every().day.at("09:00").do(automated_task)\n\nprint("Automation script initialized")\nwhile True:\n    schedule.run_pending()\n    time.sleep(60)`;
            this.insertSuggestion(script);
        }, 2000);
    }
    
    getContentRecommendation() {
        this.showNotification('AI is finding personalized recommendations...', 'info');
        setTimeout(() => {
            const recommendations = [
                "Based on your interests, we recommend 'Advanced JavaScript Patterns' course",
                "You might like our 'Web Scraping with Python' tutorial",
                "Check out our new 'React Performance Optimization' guide"
            ];
            const recommendation = recommendations[Math.floor(Math.random() * recommendations.length)];
            this.showNotification(recommendation, 'success');
        }, 1500);
    }
    
    insertSuggestion(suggestion) {
        // Insert suggestion into current active editor or textarea
        const activeElement = document.activeElement;
        if (activeElement && (activeElement.tagName === 'TEXTAREA' || activeElement.tagName === 'INPUT')) {
            const start = activeElement.selectionStart;
            const end = activeElement.selectionEnd;
            const text = activeElement.value;
            activeElement.value = text.substring(0, start) + suggestion + text.substring(end);
            activeElement.selectionStart = activeElement.selectionEnd = start + suggestion.length;
        }
    }
    
    unlockPremiumFeatures() {
        // Remove premium locks
        document.querySelectorAll('.premium-lock, .btn-premium').forEach(element => {
            if (element.classList.contains('btn-premium')) {
                element.classList.remove('btn-premium');
                element.classList.add('btn-primary');
                element.removeAttribute('onclick');
            }
        });
        
        // Enable AI features
        document.querySelectorAll('[data-ai-feature]').forEach(button => {
            button.disabled = false;
            button.style.opacity = '1';
        });
        
        // Update UI
        this.updatePremiumUI();
    }
    
    updateUIForUser() {
        // Update navigation
        const premiumNavBtn = document.querySelector('.nav-links .btn-premium');
        if (premiumNavBtn) {
            if (this.isPremium) {
                premiumNavBtn.innerHTML = '<i class="fas fa-crown"></i> Premium Active';
                premiumNavBtn.style.background = 'linear-gradient(45deg, #FFD700, #FFA500)';
            }
        }
        
        // Update user profile
        this.updatePremiumUI();
    }
    
    updatePremiumUI() {
        // Show/hide premium content based on subscription
        document.querySelectorAll('[data-premium="true"]').forEach(element => {
            if (this.isPremium) {
                element.style.display = '';
                element.style.opacity = '1';
            } else {
                element.style.opacity = '0.6';
                element.style.pointerEvents = 'none';
            }
        });
    }
    
    saveUserData() {
        localStorage.setItem('krrevive_user', JSON.stringify(this.user));
    }
    
    // Utility functions
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--secondary-dark);
            border: 2px solid ${type === 'success' ? 'var(--neon-green)' : type === 'warning' ? 'var(--neon-yellow)' : 'var(--neon-cyan)'};
            border-radius: 10px;
            padding: 1rem;
            z-index: 3000;
            max-width: 300px;
            animation: slideIn 0.3s ease-out;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    showLoading(message) {
        this.showNotification(message, 'info');
    }
    
    showSuccess(message) {
        this.showNotification(message, 'success');
    }
    
    showError(message) {
        this.showNotification(message, 'error');
    }
    
    trackEvent(eventName, data = {}) {
        // Analytics tracking
        console.log('Event tracked:', eventName, data);
        
        // In production, send to analytics service
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, data);
        }
    }
    
    simulatePayment(paymentData) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simulate 95% success rate
                if (Math.random() < 0.95) {
                    resolve(paymentData);
                } else {
                    reject(new Error('Payment simulation failed'));
                }
            }, 1500);
        });
    }
    
    // Public methods
    isUserPremium() {
        return this.isPremium;
    }
    
    getUserSubscription() {
        return this.subscription;
    }
    
    logout() {
        this.user = null;
        this.isPremium = false;
        this.subscription = null;
        localStorage.removeItem('krrevive_user');
        location.reload();
    }
}

// Initialize subscription manager
document.addEventListener('DOMContentLoaded', () => {
    window.subscriptionManager = new SubscriptionManager();
    
    // Global functions for onclick handlers
    window.showSubscriptionModal = () => subscriptionManager.showSubscriptionModal();
    window.closeSubscriptionModal = () => subscriptionManager.closeSubscriptionModal();
    window.processPayment = (plan) => subscriptionManager.processPayment(plan);
    window.processPaymentPaypal = (plan) => subscriptionManager.processPaymentPaypal(plan);
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SubscriptionManager;
}