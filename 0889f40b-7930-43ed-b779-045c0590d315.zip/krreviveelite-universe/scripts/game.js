// KRREVIVEÉLITE Cyber Arena Game JavaScript
// Canvas-based cyber-themed arcade game

class CyberArenaGame {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        
        // Game state
        this.gameRunning = false;
        this.gamePaused = false;
        this.score = 0;
        this.lives = 3;
        this.level = 1;
        this.wave = 1;
        
        // Game objects
        this.player = null;
        this.bullets = [];
        this.enemies = [];
        this.particles = [];
        this.powerUps = [];
        
        // Game settings
        this.settings = {
            playerSpeed: 5,
            bulletSpeed: 8,
            enemyBaseSpeed: 1,
            particleCount: 20,
            powerUpDuration: 5000
        };
        
        // Input handling
        this.keys = {};
        
        // Premium features
        this.isPremium = false;
        this.activePowerUps = [];
        
        this.init();
    }
    
    init() {
        this.setupCanvas();
        this.createPlayer();
        this.setupEventListeners();
        this.setupUI();
        this.drawGame();
    }
    
    setupCanvas() {
        // Set canvas size
        this.canvas.width = 800;
        this.canvas.height = 500;
        
        // Handle high DPI displays
        const dpr = window.devicePixelRatio || 1;
        const rect = this.canvas.getBoundingClientRect();
        this.canvas.width = rect.width * dpr;
        this.canvas.height = rect.height * dpr;
        this.ctx.scale(dpr, dpr);
        this.canvas.style.width = rect.width + 'px';
        this.canvas.style.height = rect.height + 'px';
    }
    
    createPlayer() {
        this.player = {
            x: this.canvas.width / (2 * (window.devicePixelRatio || 1)) - 25,
            y: this.canvas.height / (window.devicePixelRatio || 1) - 80,
            width: 50,
            height: 50,
            speed: this.settings.playerSpeed,
            color: '#00ffea',
            shield: false,
            rapidFire: false
        };
    }
    
    setupEventListeners() {
        // Keyboard controls
        document.addEventListener('keydown', (e) => {
            this.keys[e.key] = true;
            
            if (e.key === 'p' || e.key === 'P') {
                this.togglePause();
            }
            
            if (e.key === ' ' && this.gameRunning && !this.gamePaused) {
                e.preventDefault();
                this.shoot();
            }
            
            // Weapon switching (premium)
            if ((e.key === '1' || e.key === '2' || e.key === '3') && this.isPremium) {
                this.switchWeapon(parseInt(e.key));
            }
        });
        
        document.addEventListener('keyup', (e) => {
            this.keys[e.key] = false;
        });
        
        // Mouse/touch controls for mobile
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            const rect = this.canvas.getBoundingClientRect();
            const x = touch.clientX - rect.left;
            
            // Move player to touch position
            this.player.x = Math.max(0, Math.min(x - this.player.width / 2, rect.width - this.player.width));
            
            if (this.gameRunning && !this.gamePaused) {
                this.shoot();
            }
        });
        
        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            const rect = this.canvas.getBoundingClientRect();
            const x = touch.clientX - rect.left;
            
            this.player.x = Math.max(0, Math.min(x - this.player.width / 2, rect.width - this.player.width));
        });
    }
    
    setupUI() {
        // Update UI elements
        this.updateStats();
        
        // Setup button event listeners
        const startBtn = document.getElementById('startBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const resetBtn = document.getElementById('resetBtn');
        
        if (startBtn) startBtn.addEventListener('click', () => this.startGame());
        if (pauseBtn) pauseBtn.addEventListener('click', () => this.togglePause());
        if (resetBtn) resetBtn.addEventListener('click', () => this.resetGame());
    }
    
    startGame() {
        if (!this.gameRunning) {
            this.gameRunning = true;
            this.gamePaused = false;
            this.resetGameState();
            
            // Update UI
            const startBtn = document.getElementById('startBtn');
            const pauseBtn = document.getElementById('pauseBtn');
            if (startBtn) startBtn.disabled = true;
            if (pauseBtn) pauseBtn.disabled = false;
            
            this.gameLoop();
            this.startEnemySpawning();
        }
    }
    
    togglePause() {
        if (!this.gameRunning) return;
        
        this.gamePaused = !this.gamePaused;
        const pauseBtn = document.getElementById('pauseBtn');
        if (pauseBtn) {
            pauseBtn.innerHTML = this.gamePaused ? 
                '<i class="fas fa-play"></i> Resume' : 
                '<i class="fas fa-pause"></i> Pause';
        }
        
        if (!this.gamePaused) {
            this.gameLoop();
        }
    }
    
    resetGame() {
        this.gameRunning = false;
        this.gamePaused = false;
        this.resetGameState();
        
        // Update UI
        const startBtn = document.getElementById('startBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        if (startBtn) startBtn.disabled = false;
        if (pauseBtn) {
            pauseBtn.disabled = true;
            pauseBtn.innerHTML = '<i class="fas fa-pause"></i> Pause';
        }
        
        this.drawGame();
    }
    
    resetGameState() {
        this.score = 0;
        this.lives = 3;
        this.level = 1;
        this.wave = 1;
        this.bullets = [];
        this.enemies = [];
        this.particles = [];
        this.powerUps = [];
        this.activePowerUps = [];
        this.createPlayer();
        this.updateStats();
    }
    
    gameLoop() {
        if (!this.gameRunning || this.gamePaused) return;
        
        this.updateGame();
        this.drawGame();
        
        requestAnimationFrame(() => this.gameLoop());
    }
    
    updateGame() {
        this.updatePlayer();
        this.updateBullets();
        this.updateEnemies();
        this.updateParticles();
        this.updatePowerUps();
        this.checkCollisions();
        this.updateActivePowerUps();
    }
    
    updatePlayer() {
        // Keyboard movement
        if (this.keys['ArrowLeft'] && this.player.x > 0) {
            this.player.x -= this.player.speed;
        }
        if (this.keys['ArrowRight'] && this.player.x < this.canvas.width / (window.devicePixelRatio || 1) - this.player.width) {
            this.player.x += this.player.speed;
        }
    }
    
    updateBullets() {
        this.bullets = this.bullets.filter(bullet => {
            bullet.y -= bullet.speed;
            return bullet.y > -bullet.height;
        });
    }
    
    updateEnemies() {
        this.enemies = this.enemies.filter(enemy => {
            enemy.y += enemy.speed;
            
            // Simple enemy movement pattern
            if (enemy.pattern === 'zigzag') {
                enemy.x += Math.sin(enemy.y * 0.05) * 2;
            }
            
            // Remove enemies that go off screen
            if (enemy.y > this.canvas.height / (window.devicePixelRatio || 1) + enemy.height) {
                this.lives--;
                this.updateStats();
                this.createExplosion(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, '#ff0055');
                
                if (this.lives <= 0) {
                    this.gameOver();
                }
                
                return false;
            }
            
            return true;
        });
    }
    
    updateParticles() {
        this.particles = this.particles.filter(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.life -= 0.02;
            particle.vy += 0.1; // Gravity
            return particle.life > 0;
        });
    }
    
    updatePowerUps() {
        this.powerUps = this.powerUps.filter(powerUp => {
            powerUp.y += powerUp.speed;
            powerUp.rotation += powerUp.rotationSpeed;
            
            // Remove if off screen
            return powerUp.y < this.canvas.height / (window.devicePixelRatio || 1) + powerUp.size;
        });
    }
    
    updateActivePowerUps() {
        const now = Date.now();
        this.activePowerUps = this.activePowerUps.filter(powerUp => {
            if (now > powerUp.endTime) {
                // Deactivate power-up
                this.deactivatePowerUp(powerUp.type);
                return false;
            }
            return true;
        });
    }
    
    checkCollisions() {
        // Check bullet-enemy collisions
        this.bullets.forEach((bullet, bulletIndex) => {
            this.enemies.forEach((enemy, enemyIndex) => {
                if (this.isColliding(bullet, enemy)) {
                    enemy.health--;
                    
                    if (enemy.health <= 0) {
                        this.score += enemy.points * this.level;
                        this.updateStats();
                        this.createExplosion(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, enemy.color);
                        
                        // Chance to drop power-up
                        if (Math.random() < 0.1) {
                            this.createPowerUp(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2);
                        }
                        
                        this.enemies.splice(enemyIndex, 1);
                        
                        // Level up every 1000 points
                        if (this.score > 0 && this.score % 1000 === 0) {
                            this.levelUp();
                        }
                    }
                    
                    this.bullets.splice(bulletIndex, 1);
                }
            });
        });
        
        // Check player-enemy collisions
        this.enemies.forEach((enemy, enemyIndex) => {
            if (this.isColliding(this.player, enemy)) {
                if (!this.player.shield) {
                    this.lives--;
                    this.updateStats();
                    this.createExplosion(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, '#ff0055');
                    
                    if (this.lives <= 0) {
                        this.gameOver();
                    }
                } else {
                    this.createExplosion(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, '#00ffea');
                }
                
                this.enemies.splice(enemyIndex, 1);
            }
        });
        
        // Check player-powerUp collisions
        this.powerUps.forEach((powerUp, powerUpIndex) => {
            if (this.isColliding(this.player, powerUp)) {
                this.activatePowerUp(powerUp.type);
                this.powerUps.splice(powerUpIndex, 1);
            }
        });
    }
    
    isColliding(obj1, obj2) {
        return obj1.x < obj2.x + obj2.width &&
               obj1.x + obj1.width > obj2.x &&
               obj1.y < obj2.y + obj2.height &&
               obj1.y + obj1.height > obj2.y;
    }
    
    shoot() {
        const bulletCount = this.player.rapidFire ? 3 : 1;
        const bulletSpread = 15;
        
        for (let i = 0; i < bulletCount; i++) {
            const xOffset = (i - Math.floor(bulletCount / 2)) * bulletSpread;
            
            this.bullets.push({
                x: this.player.x + this.player.width / 2 - 2 + xOffset,
                y: this.player.y,
                width: 4,
                height: 10,
                speed: this.settings.bulletSpeed,
                color: this.player.rapidFire ? '#ff00ff' : '#00ff41'
            });
        }
    }
    
    createExplosion(x, y, color = '#ff5500') {
        for (let i = 0; i < this.settings.particleCount; i++) {
            const angle = (Math.PI * 2 * i) / this.settings.particleCount;
            const speed = Math.random() * 4 + 2;
            
            this.particles.push({
                x: x,
                y: y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: Math.random() * 3 + 1,
                color: this.hexToRgb(color),
                life: 1
            });
        }
    }
    
    createPowerUp(x, y) {
        const types = this.isPremium ? 
            ['rapidFire', 'shield', 'megaBlast', 'ghostMode'] : 
            ['rapidFire', 'shield'];
        
        const type = types[Math.floor(Math.random() * types.length)];
        const colors = {
            rapidFire: '#ffff00',
            shield: '#00ffea',
            megaBlast: '#ff00ff',
            ghostMode: '#9400d3'
        };
        
        this.powerUps.push({
            x: x - 15,
            y: y - 15,
            width: 30,
            height: 30,
            speed: 2,
            type: type,
            color: colors[type],
            rotation: 0,
            rotationSpeed: 0.05
        });
    }
    
    activatePowerUp(type) {
        if (!this.isPremium && (type === 'megaBlast' || type === 'ghostMode')) {
            this.showPremiumMessage('This power-up requires a premium subscription!');
            return;
        }
        
        const duration = this.settings.powerUpDuration;
        
        switch (type) {
            case 'rapidFire':
                this.player.rapidFire = true;
                break;
            case 'shield':
                this.player.shield = true;
                break;
            case 'megaBlast':
                // Implement mega blast
                this.megaBlast();
                break;
            case 'ghostMode':
                this.player.ghostMode = true;
                break;
        }
        
        this.activePowerUps.push({
            type: type,
            endTime: Date.now() + duration
        });
        
        this.showMessage(`Power-up activated: ${type}`, 'success');
    }
    
    deactivatePowerUp(type) {
        switch (type) {
            case 'rapidFire':
                this.player.rapidFire = false;
                break;
            case 'shield':
                this.player.shield = false;
                break;
            case 'ghostMode':
                this.player.ghostMode = false;
                break;
        }
    }
    
    megaBlast() {
        // Create a massive blast that destroys all enemies
        this.enemies.forEach(enemy => {
            this.score += enemy.points;
            this.createExplosion(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, enemy.color);
        });
        this.enemies = [];
        this.updateStats();
    }
    
    startEnemySpawning() {
        const spawnWave = () => {
            if (!this.gameRunning || this.gamePaused) return;
            
            const enemyCount = Math.min(3 + Math.floor(this.wave / 2), 8);
            
            for (let i = 0; i < enemyCount; i++) {
                setTimeout(() => {
                    if (this.gameRunning && !this.gamePaused) {
                        this.spawnEnemy();
                    }
                }, i * 500);
            }
            
            // Schedule next wave
            setTimeout(() => {
                if (this.gameRunning) {
                    this.wave++;
                    this.updateStats();
                    spawnWave();
                }
            }, 5000 + this.wave * 1000);
        };
        
        spawnWave();
    }
    
    spawnEnemy() {
        const enemyTypes = [
            { color: '#ff0055', health: 1, speed: 1, points: 100, pattern: 'straight' },
            { color: '#ff00aa', health: 2, speed: 1.5, points: 150, pattern: 'zigzag' },
            { color: '#aa00ff', health: 3, speed: 0.8, points: 200, pattern: 'straight' }
        ];
        
        const type = enemyTypes[Math.floor(Math.random() * Math.min(enemyTypes.length, this.level))];
        const canvasWidth = this.canvas.width / (window.devicePixelRatio || 1);
        
        this.enemies.push({
            x: Math.random() * (canvasWidth - 40),
            y: -50,
            width: 40,
            height: 40,
            speed: type.speed + (this.wave * 0.2),
            color: type.color,
            health: type.health,
            points: type.points,
            pattern: type.pattern
        });
    }
    
    levelUp() {
        this.level++;
        this.showMessage(`Level ${this.level}!`, 'success');
        
        // Restore a life every few levels
        if (this.level % 3 === 0) {
            this.lives++;
            this.updateStats();
            this.showMessage('Extra life!', 'success');
        }
    }
    
    drawGame() {
        const canvas = this.canvas;
        const ctx = this.ctx;
        const dpr = window.devicePixelRatio || 1;
        
        // Clear canvas
        ctx.fillStyle = '#0a0a0a';
        ctx.fillRect(0, 0, canvas.width / dpr, canvas.height / dpr);
        
        // Draw grid background
        this.drawGrid();
        
        // Draw game objects
        this.drawPlayer();
        this.drawBullets();
        this.drawEnemies();
        this.drawParticles();
        this.drawPowerUps();
        
        // Draw UI overlay
        if (this.gamePaused) {
            this.drawPauseScreen();
        }
        
        if (!this.gameRunning && this.lives <= 0) {
            this.drawGameOverScreen();
        }
    }
    
    drawGrid() {
        const ctx = this.ctx;
        const canvasWidth = this.canvas.width / (window.devicePixelRatio || 1);
        const canvasHeight = this.canvas.height / (window.devicePixelRatio || 1);
        
        ctx.strokeStyle = 'rgba(0, 255, 234, 0.1)';
        ctx.lineWidth = 1;
        
        // Vertical lines
        for (let i = 0; i < canvasWidth; i += 50) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, canvasHeight);
            ctx.stroke();
        }
        
        // Horizontal lines
        for (let i = 0; i < canvasHeight; i += 50) {
            ctx.beginPath();
            ctx.moveTo(0, i);
            ctx.lineTo(canvasWidth, i);
            ctx.stroke();
        }
    }
    
    drawPlayer() {
        const ctx = this.ctx;
        
        // Draw shield if active
        if (this.player.shield) {
            ctx.fillStyle = 'rgba(0, 255, 234, 0.3)';
            ctx.beginPath();
            ctx.arc(
                this.player.x + this.player.width / 2,
                this.player.y + this.player.height / 2,
                this.player.width,
                0,
                Math.PI * 2
            );
            ctx.fill();
        }
        
        // Draw player ship
        ctx.fillStyle = this.player.ghostMode ? 'rgba(0, 255, 234, 0.5)' : this.player.color;
        ctx.fillRect(this.player.x, this.player.y, this.player.width, this.player.height);
        
        // Draw player details
        ctx.fillStyle = '#fff';
        ctx.fillRect(this.player.x + 20, this.player.y + 10, 10, 30);
        ctx.fillRect(this.player.x + 10, this.player.y + 20, 30, 10);
    }
    
    drawBullets() {
        const ctx = this.ctx;
        
        this.bullets.forEach(bullet => {
            ctx.fillStyle = bullet.color;
            ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
            
            // Add glow effect
            ctx.shadowBlur = 10;
            ctx.shadowColor = bullet.color;
            ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
            ctx.shadowBlur = 0;
        });
    }
    
    drawEnemies() {
        const ctx = this.ctx;
        
        this.enemies.forEach(enemy => {
            ctx.fillStyle = enemy.color;
            ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
            
            // Draw enemy details
            ctx.fillStyle = '#fff';
            ctx.fillRect(enemy.x + 15, enemy.y + 10, 10, 20);
            ctx.fillRect(enemy.x + 5, enemy.y + 15, 30, 10);
            
            // Health indicator
            if (enemy.health > 1) {
                ctx.fillStyle = '#ff0000';
                ctx.fillRect(enemy.x, enemy.y - 10, enemy.width * (enemy.health / 3), 3);
            }
        });
    }
    
    drawParticles() {
        const ctx = this.ctx;
        
        this.particles.forEach(particle => {
            ctx.fillStyle = `rgba(${particle.color}, ${particle.life})`;
            ctx.fillRect(particle.x, particle.y, particle.size, particle.size);
        });
    }
    
    drawPowerUps() {
        const ctx = this.ctx;
        
        this.powerUps.forEach(powerUp => {
            ctx.save();
            ctx.translate(powerUp.x + powerUp.width / 2, powerUp.y + powerUp.height / 2);
            ctx.rotate(powerUp.rotation);
            
            ctx.fillStyle = powerUp.color;
            ctx.fillRect(-powerUp.width / 2, -powerUp.height / 2, powerUp.width, powerUp.height);
            
            // Draw power-up icon
            ctx.fillStyle = '#fff';
            ctx.font = '16px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            
            const icons = {
                rapidFire: '⚡',
                shield: '🛡',
                megaBlast: '💥',
                ghostMode: '👻'
            };
            
            ctx.fillText(icons[powerUp.type] || '⚡', 0, 0);
            
            ctx.restore();
        });
    }
    
    drawPauseScreen() {
        const ctx = this.ctx;
        const canvasWidth = this.canvas.width / (window.devicePixelRatio || 1);
        const canvasHeight = this.canvas.height / (window.devicePixelRatio || 1);
        
        ctx.fillStyle = '#00ffea';
        ctx.font = 'bold 48px Orbitron';
        ctx.textAlign = 'center';
        ctx.fillText('PAUSED', canvasWidth / 2, canvasHeight / 2);
    }
    
    drawGameOverScreen() {
        const ctx = this.ctx;
        const canvasWidth = this.canvas.width / (window.devicePixelRatio || 1);
        const canvasHeight = this.canvas.height / (window.devicePixelRatio || 1);
        
        ctx.fillStyle = '#ff0055';
        ctx.font = 'bold 48px Orbitron';
        ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', canvasWidth / 2, canvasHeight / 2);
        
        ctx.fillStyle = '#fff';
        ctx.font = '20px Orbitron';
        ctx.fillText(`Final Score: ${this.score}`, canvasWidth / 2, canvasHeight / 2 + 40);
    }
    
    updateStats() {
        document.getElementById('score').textContent = this.score;
        document.getElementById('lives').textContent = this.lives;
        document.getElementById('level').textContent = this.level;
        document.getElementById('wave').textContent = this.wave;
    }
    
    gameOver() {
        this.gameRunning = false;
        
        // Update final score modal
        const finalScoreEl = document.getElementById('finalScore');
        const finalWaveEl = document.getElementById('finalWave');
        const gameOverModal = document.getElementById('gameOverModal');
        
        if (finalScoreEl) finalScoreEl.textContent = this.score;
        if (finalWaveEl) finalWaveEl.textContent = this.wave;
        if (gameOverModal) gameOverModal.classList.add('active');
        
        // Save score to leaderboard (in real app)
        this.saveScore();
    }
    
    saveScore() {
        // Save score to local storage or send to server
        const scoreData = {
            score: this.score,
            wave: this.wave,
            level: this.level,
            timestamp: new Date().toISOString()
        };
        
        let scores = JSON.parse(localStorage.getItem('cyberArenaScores') || '[]');
        scores.push(scoreData);
        scores.sort((a, b) => b.score - a.score);
        scores = scores.slice(0, 10); // Keep top 10
        
        localStorage.setItem('cyberArenaScores', JSON.stringify(scores));
    }
    
    showMessage(message, type = 'info') {
        // Create temporary message
        const messageEl = document.createElement('div');
        messageEl.textContent = message;
        messageEl.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: var(--secondary-dark);
            border: 2px solid var(--neon-cyan);
            border-radius: 10px;
            padding: 1rem 2rem;
            color: var(--text-primary);
            font-family: 'Orbitron', monospace;
            font-weight: bold;
            z-index: 1000;
            animation: fadeInOut 2s ease-in-out;
        `;
        
        document.body.appendChild(messageEl);
        
        setTimeout(() => {
            messageEl.remove();
        }, 2000);
    }
    
    showPremiumMessage(message) {
        this.showMessage(message, 'warning');
        
        // Show subscription modal
        const modal = document.getElementById('subscriptionModal');
        if (modal) {
            modal.classList.add('active');
        }
    }
    
    switchWeapon(weaponNumber) {
        // Premium feature: switch between different weapons
        const weapons = {
            1: { name: 'Standard', color: '#00ff41' },
            2: { name: 'Plasma', color: '#ff00ff' },
            3: { name: 'Laser', color: '#ff0000' }
        };
        
        const weapon = weapons[weaponNumber];
        if (weapon) {
            this.showMessage(`Weapon switched to: ${weapon.name}`, 'success');
            // Update bullet color, speed, etc.
        }
    }
    
    // Utility function to convert hex to RGB
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? 
            `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}` : 
            '255, 255, 255';
    }
    
    // Public methods
    setPremiumStatus(isPremium) {
        this.isPremium = isPremium;
        if (isPremium) {
            this.showMessage('Premium features unlocked!', 'success');
        }
    }
    
    getGameState() {
        return {
            score: this.score,
            lives: this.lives,
            level: this.level,
            wave: this.wave,
            isRunning: this.gameRunning,
            isPaused: this.gamePaused
        };
    }
}

// Initialize game when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    const game = new CyberArenaGame('gameCanvas');
    window.cyberArenaGame = game;
    
    // Make game globally available for button clicks
    window.startGame = () => game.startGame();
    window.pauseGame = () => game.togglePause();
    window.resetGame = () => game.resetGame();
    window.activatePowerUp = (type) => game.activatePowerUp(type);
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CyberArenaGame;
}