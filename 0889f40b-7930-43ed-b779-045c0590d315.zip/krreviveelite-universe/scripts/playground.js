// KRREVIVEÉLITE Coding Playground JavaScript
// Live code editor with AI assistance and templates

class CodePlayground {
    constructor() {
        this.editors = {};
        this.currentTab = 'html';
        this.templates = {};
        this.isPremium = false;
        this.init();
    }
    
    init() {
        this.initializeEditors();
        this.loadTemplates();
        this.setupEventListeners();
        this.setupKeyboardShortcuts();
        this.setupAIIntegration();
    }
    
    initializeEditors() {
        // Initialize CodeMirror editors for HTML, CSS, and JavaScript
        const editorConfig = {
            lineNumbers: true,
            lineWrapping: true,
            autoCloseBrackets: true,
            matchBrackets: true,
            indentUnit: 4,
            tabSize: 4,
            theme: 'monokai',
            extraKeys: {
                "Ctrl-Space": "autocomplete",
                "Ctrl-S": () => this.saveCode(),
                "Ctrl-Enter": () => this.runCode(),
                "F11": () => this.toggleFullscreen()
            }
        };
        
        // HTML Editor
        this.editors.html = CodeMirror.fromTextArea(document.getElementById('html-editor'), {
            ...editorConfig,
            mode: 'xml',
            autoCloseTags: true
        });
        
        // CSS Editor
        this.editors.css = CodeMirror.fromTextArea(document.getElementById('css-editor'), {
            ...editorConfig,
            mode: 'css'
        });
        
        // JavaScript Editor
        this.editors.js = CodeMirror.fromTextArea(document.getElementById('js-editor'), {
            ...editorConfig,
            mode: 'javascript'
        });
        
        // Set up change listeners for live preview
        Object.values(this.editors).forEach(editor => {
            editor.on('change', () => this.debounce(() => this.updatePreview(), 500));
        });
    }
    
    loadTemplates() {
        this.templates = {
            blank: {
                html: '<!-- Your HTML here -->\n<div>\n  <h1>Hello World!</h1>\n</div>',
                css: '/* Your CSS here */\nbody {\n  font-family: Arial, sans-serif;\n  margin: 0;\n  padding: 20px;\n}',
                js: '// Your JavaScript here\nconsole.log("Hello World!");'
            },
            bootstrap: {
                html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bootstrap Template</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h1 class="card-title">Bootstrap Card</h1>
                        <p class="card-text">This is a Bootstrap card component.</p>
                        <button class="btn btn-primary">Primary Button</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`,
                css: `/* Bootstrap custom styles */
.card {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
}`,
                js: `// Bootstrap interactions
document.addEventListener('DOMContentLoaded', function() {
    console.log('Bootstrap template loaded!');
});`
            },
            react: {
                html: '<div id="root"></div>',
                css: `.App {
  text-align: center;
  padding: 20px;
}

.card {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
  margin: 20px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}`,
                js: `// React-like component structure
class App {
  constructor() {
    this.state = {
      message: "Hello from React-like structure!"
    };
  }
  
  render() {
    return \`
      <div class="App">
        <h1>\${this.state.message}</h1>
        <div class="card">
          <h2>Component Card</h2>
          <p>This is a React-inspired component structure.</p>
        </div>
      </div>
    \`;
  }
}

// Render the app
const app = new App();
document.getElementById('root').innerHTML = app.render();`
            },
            vue: {
                html: `<div id="app">
  <div class="vue-container">
    <h1>{{ title }}</h1>
    <p>{{ message }}</p>
    <button v-on:click="sayHello">Click Me</button>
  </div>
</div>`,
                css: `.vue-container {
  max-width: 600px;
  margin: 50px auto;
  padding: 20px;
  text-align: center;
  background: #f8f9fa;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

button {
  background: #42b883;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}`,
                js: `// Vue-like reactivity simulation
const app = {
  data: {
    title: "Vue-like Template",
    message: "This is a Vue-inspired template structure!"
  },
  methods: {
    sayHello() {
      alert("Hello from Vue-like structure!");
    }
  }
};

// Simulate template rendering
document.getElementById('app').innerHTML = 
  document.getElementById('app').innerHTML
    .replace(/{{ title }}/g, app.data.title)
    .replace(/{{ message }}/g, app.data.message);
    
// Add event listeners
document.querySelector('button').addEventListener('click', app.methods.sayHello);`
            }
        };
    }
    
    setupEventListeners() {
        // Tab switching
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => this.switchTab(e.target.closest('.tab-button')));
        });
        
        // Template selection
        document.querySelectorAll('.template-btn').forEach(button => {
            button.addEventListener('click', (e) => this.loadTemplate(e.target.closest('.template-btn')));
        });
        
        // AI suggestions
        document.querySelectorAll('.ai-suggestion-item').forEach(item => {
            item.addEventListener('click', (e) => this.applyAISuggestion(e.target.closest('.ai-suggestion-item')));
        });
        
        // Action buttons
        const runBtn = document.getElementById('runBtn');
        const formatBtn = document.getElementById('formatBtn');
        const clearBtn = document.getElementById('clearBtn');
        const downloadBtn = document.getElementById('downloadBtn');
        
        if (runBtn) runBtn.addEventListener('click', () => this.runCode());
        if (formatBtn) formatBtn.addEventListener('click', () => this.formatCode());
        if (clearBtn) clearBtn.addEventListener('click', () => this.clearCode());
        if (downloadBtn) downloadBtn.addEventListener('click', () => this.downloadCode());
    }
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 's':
                        e.preventDefault();
                        this.saveCode();
                        break;
                    case 'Enter':
                        e.preventDefault();
                        this.runCode();
                        break;
                }
            }
        });
    }
    
    setupAIIntegration() {
        // Check if AI tools are available
        if (window.aiToolsManager) {
            this.aiAvailable = true;
        }
    }
    
    switchTab(tabButton) {
        // Remove active class from all tabs
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to clicked tab
        tabButton.classList.add('active');
        
        // Get tab name from button text or data attribute
        const tabName = tabButton.textContent.toLowerCase().includes('html') ? 'html' :
                       tabButton.textContent.toLowerCase().includes('css') ? 'css' : 'js';
        
        this.currentTab = tabName;
        
        // Update editor panels
        document.querySelectorAll('.editor-pane').forEach(pane => {
            pane.classList.remove('active');
        });
        document.getElementById(`${tabName}-pane`).classList.add('active');
        
        // Focus the current editor
        if (this.editors[tabName]) {
            this.editors[tabName].focus();
        }
    }
    
    loadTemplate(templateButton) {
        const templateName = templateButton.textContent.toLowerCase().includes('blank') ? 'blank' :
                             templateButton.textContent.toLowerCase().includes('bootstrap') ? 'bootstrap' :
                             templateButton.textContent.toLowerCase().includes('react') ? 'react' :
                             templateButton.textContent.toLowerCase().includes('vue') ? 'vue' : null;
        
        if (templateName && this.templates[templateName]) {
            // Check if template is premium
            if (templateButton.classList.contains('premium') && !this.isPremium) {
                this.showPremiumUpgrade();
                return;
            }
            
            const template = this.templates[templateName];
            this.editors.html.setValue(template.html);
            this.editors.css.setValue(template.css);
            this.editors.js.setValue(template.js);
            this.updatePreview();
            
            this.showNotification(`Template "${templateName}" loaded successfully`, 'success');
        }
    }
    
    applyAISuggestion(suggestionItem) {
        const suggestionText = suggestionItem.textContent.trim();
        const suggestions = {
            'html-boilerplate': this.getHTMLBoilerplate(),
            'responsive-grid': this.getResponsiveGridCSS(),
            'dark-mode-toggle': this.getDarkModeToggleJS(),
            'component-generator': () => this.generateComponent(),
            'performance-optimizer': () => this.optimizeCode()
        };
        
        // Match suggestion text to available suggestions
        const suggestionKey = Object.keys(suggestions).find(key => 
            suggestionText.toLowerCase().includes(key.toLowerCase().replace(/-/g, ' '))
        );
        
        if (suggestionKey) {
            if (typeof suggestions[suggestionKey] === 'function') {
                suggestions[suggestionKey]();
            } else {
                this.editors[this.currentTab].replaceSelection(suggestions[suggestionKey]);
            }
            
            if (suggestionItem.classList.contains('premium') && !this.isPremium) {
                this.showPremiumUpgrade();
                return;
            }
            
            this.showNotification(`AI suggestion applied: ${suggestionKey}`, 'success');
        } else {
            this.showNotification('AI suggestion not available', 'warning');
        }
    }
    
    updatePreview() {
        const html = this.editors.html.getValue();
        const css = this.editors.css.getValue();
        const js = this.editors.js.getValue();
        
        let previewContent = this.buildPreviewContent(html, css, js);
        
        const previewFrame = document.getElementById('preview-frame');
        if (previewFrame) {
            previewFrame.srcdoc = previewContent;
        }
        
        // Update console output
        this.addConsoleMessage('Preview updated', 'info');
    }
    
    buildPreviewContent(html, css, js) {
        // If no full HTML document, create one
        if (!html.includes('<!DOCTYPE')) {
            return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview</title>
    <style>${css}</style>
</head>
<body>
    ${html}
    <script>
        try {
            ${js}
        } catch (error) {
            console.error('JavaScript Error:', error);
        }
    </script>
</body>
</html>`;
        }
        
        // Insert CSS and JS into existing HTML
        let result = html;
        if (!result.includes('<style>') && css.trim()) {
            result = result.replace('</head>', `<style>${css}</style></head>`);
        }
        if (!result.includes('<script>') && js.trim()) {
            result = result.replace('</body>', `<script>${js}</script></body>`);
        }
        
        return result;
    }
    
    formatCode() {
        const editor = this.editors[this.currentTab];
        const code = editor.getValue();
        
        // Simple formatting (in production, use proper formatter like Prettier)
        let formatted = code;
        if (this.currentTab === 'html') {
            formatted = this.formatHTML(code);
        } else if (this.currentTab === 'css') {
            formatted = this.formatCSS(code);
        } else if (this.currentTab === 'js') {
            formatted = this.formatJS(code);
        }
        
        editor.setValue(formatted);
        this.addConsoleMessage('Code formatted', 'success');
    }
    
    clearCode() {
        if (confirm('Are you sure you want to clear the current code?')) {
            this.editors[this.currentTab].setValue('');
            this.addConsoleMessage('Code cleared', 'info');
        }
    }
    
    runCode() {
        this.updatePreview();
        this.addConsoleMessage('Code executed successfully', 'success');
    }
    
    downloadCode() {
        if (!this.isPremium) {
            this.showPremiumUpgrade('Code download requires a premium subscription!');
            return;
        }
        
        const html = this.editors.html.getValue();
        const css = this.editors.css.getValue();
        const js = this.editors.js.getValue();
        
        const fullCode = this.buildPreviewContent(html, css, js);
        
        // Create download link
        const blob = new Blob([fullCode], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'playground-project.html';
        a.click();
        
        this.addConsoleMessage('Code downloaded', 'success');
    }
    
    saveCode() {
        // Save to localStorage or cloud (premium feature)
        const code = {
            html: this.editors.html.getValue(),
            css: this.editors.css.getValue(),
            js: this.editors.js.getValue(),
            timestamp: new Date().toISOString()
        };
        
        localStorage.setItem('playground-autosave', JSON.stringify(code));
        this.addConsoleMessage('Code saved', 'success');
    }
    
    toggleFullscreen() {
        const playground = document.querySelector('.playground-container');
        if (!document.fullscreenElement) {
            playground.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
    }
    
    addConsoleMessage(message, type = 'info') {
        const console = document.getElementById('console-output');
        if (!console) return;
        
        const timestamp = new Date().toLocaleTimeString();
        const messageEl = document.createElement('div');
        messageEl.innerHTML = `<span style="color: ${this.getConsoleColor(type)}">[${timestamp}]</span> ${message}`;
        console.appendChild(messageEl);
        console.scrollTop = console.scrollHeight;
    }
    
    getConsoleColor(type) {
        const colors = {
            success: '#00ff41',
            error: '#ff0055',
            warning: '#ffff00',
            info: '#00ffea'
        };
        return colors[type] || '#00ffea';
    }
    
    // AI-related methods
    generateComponent() {
        if (!this.aiAvailable || !this.isPremium) {
            this.showPremiumUpgrade('Component generation requires a premium subscription!');
            return;
        }
        
        // Call AI tools manager for component generation
        if (window.aiToolsManager) {
            window.aiToolsManager.generateAIContent('component');
        }
    }
    
    optimizeCode() {
        if (!this.aiAvailable || !this.isPremium) {
            this.showPremiumUpgrade('Code optimization requires a premium subscription!');
            return;
        }
        
        // Call AI tools manager for code optimization
        if (window.aiToolsManager) {
            window.aiToolsManager.optimizeCode();
        }
    }
    
    // Template methods
    getHTMLBoilerplate() {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="home">
            <h1>Welcome</h1>
            <p>Your content here</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Your Company</p>
    </footer>
    <script src="script.js"></script>
</body>
</html>`;
    }
    
    getResponsiveGridCSS() {
        return `.container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    padding: 20px;
}

@media (max-width: 768px) {
    .container {
        grid-template-columns: 1fr;
        padding: 10px;
    }
}`;
    }
    
    getDarkModeToggleJS() {
        return `const toggle = document.createElement("button");
toggle.textContent = "🌙 Toggle Dark Mode";
toggle.style.cssText = "position: fixed; top: 20px; right: 20px; z-index: 1000; padding: 10px; border: none; border-radius: 5px; cursor: pointer;";
document.body.appendChild(toggle);

toggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    toggle.textContent = document.body.classList.contains("dark-mode") ? "☀️ Toggle Light Mode" : "🌙 Toggle Dark Mode";
});

/* Add this CSS */
.dark-mode {
    background: #1a1a1a !important;
    color: #fff !important;
}`;
    }
    
    formatHTML(code) {
        return code.replace(/></g, '>\n<');
    }
    
    formatCSS(code) {
        return code.replace(/{/g, ' {\n  ').replace(/}/g, '\n}\n').replace(/;/g, ';\n  ');
    }
    
    formatJS(code) {
        return code.replace(/{/g, ' {\n  ').replace(/}/g, '\n}\n');
    }
    
    // Utility functions
    debounce(func, wait) {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(func, wait);
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--secondary-dark);
            border: 2px solid var(--neon-cyan);
            border-radius: 10px;
            padding: 1rem;
            z-index: 3000;
            max-width: 300px;
            animation: slideIn 0.3s ease-out;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    showPremiumUpgrade() {
        this.showNotification('This feature requires a premium subscription!', 'warning');
        setTimeout(() => {
            if (window.subscriptionManager) {
                window.subscriptionManager.showSubscriptionModal();
            }
        }, 1000);
    }
    
    // Public methods
    setPremiumStatus(isPremium) {
        this.isPremium = isPremium;
    }
    
    getEditors() {
        return this.editors;
    }
}

// Initialize playground when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.playground = new CodePlayground();
    
    // Check subscription status
    if (window.subscriptionManager) {
        const isPremium = window.subscriptionManager.isUserPremium();
        window.playground.setPremiumStatus(isPremium);
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CodePlayground;
}